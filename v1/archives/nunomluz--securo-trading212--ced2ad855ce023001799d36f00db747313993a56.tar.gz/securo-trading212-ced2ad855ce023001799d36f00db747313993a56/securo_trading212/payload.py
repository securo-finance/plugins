"""Build the provider-contract-1 account and holding records."""

from datetime import date
from decimal import Decimal

from . import errors, log
from .ledger import Entry, apply, balance, balancing_trades
from .mapping import (
    CashTxn,
    Fill,
    _amount,
    instrument_info,
    iso_date,
    short_symbol,
)
from .numbers import number

CONTRACT = 1
LOGO = "trading212"
MAX_TRADES = 20_000
MAX_TRANSACTIONS = 20_000

_ZERO = Decimal(0)


def _dec(value: object) -> Decimal:
    return _amount(value) or _ZERO


def _stored(info: dict, key: str) -> Decimal | None:
    return _amount(info.get(key))


def account_record(summary: dict, cash: list[CashTxn]) -> dict:
    account_id = str(summary["id"])
    currency = summary["currency"]
    balances = summary.get("cash") or {}
    total = (
        _dec(balances.get("availableToTrade"))
        + _dec(balances.get("inPies"))
        + _dec(balances.get("reservedForOrders"))
    )
    unique: dict[str, CashTxn] = {}
    for txn in cash:
        unique.setdefault(txn.external_id, txn)
    if len(unique) > MAX_TRANSACTIONS:
        raise errors.Transient("Too many cash records for one sync.")
    return {
        "external_id": f"t212:{account_id}",
        "name": f"Trading 212 ({currency})",
        "type": "investment",
        "balance": number(total),
        "currency": currency,
        "masked_number": account_id[-4:],
        "institution_logo": LOGO,
        "transactions": [
            {
                "external_id": t.external_id,
                "description": t.description,
                "amount": number(t.amount),
                "date": t.date.isoformat(),
                "type": t.type,
                "currency": t.currency,
                "payee": t.payee,
            }
            for t in unique.values()
        ],
    }


def _fill_trade(account_id: str, fill: Fill) -> dict:
    return {
        "external_id": f"t212:{account_id}:fill:{fill.id}",
        "kind": fill.kind,
        "date": fill.date.isoformat(),
        "quantity": number(fill.quantity),
        "price": number(max(fill.price, _ZERO)),
        "fee": number(max(fill.fee, _ZERO)),
    }


def build_holdings(*, account_id: str, currency: str, positions: list[dict],
                   state: dict, today: date) -> list[dict]:
    pending: dict = state.setdefault("pending", {})
    ledger: dict = state.setdefault("ledger", {})
    instruments: dict = state.setdefault("instruments", {})
    closed: dict = state.setdefault("closed", {})

    by_ticker = {}
    for pos in positions:
        ticker = (pos.get("instrument") or {}).get("ticker")
        if ticker:
            by_ticker[ticker] = pos
    tickers = sorted(set(by_ticker) | set(ledger) | set(pending) | set(closed))
    whole_budget = MAX_TRADES - 2 * len(tickers)
    remaining = whole_budget

    holdings = []
    for ticker in tickers:
        pos = by_ticker.get(ticker)
        info = instruments.setdefault(ticker, {})
        if pos is not None:
            found = instrument_info(pos["instrument"])
            info["name"] = found["name"]
            info["isin"] = found["isin"]

        rows = pending.get(ticker) or []
        send = True
        if len(rows) > whole_budget:
            log.warning("an instrument has more trades than one sync can send; its trades are left out")
            send = False
        elif len(rows) > remaining:
            send = False
        else:
            remaining -= len(rows)

        quantity = _dec(pos.get("quantity")) if pos is not None else _ZERO
        wallet = (pos.get("walletImpact") or {}) if pos is not None else {}
        value = _dec(wallet.get("currentValue"))
        cost = _dec(wallet.get("totalCost"))
        total_cost = _amount(wallet.get("totalCost"))
        is_open = pos is not None
        if is_open and quantity > 0:
            info["last_unit_price"] = number(max(value / quantity, _ZERO))
            if total_cost is not None:
                info["last_cost_price"] = number(max(total_cost / quantity, _ZERO))

        trades = None
        if send:
            fills = [Fill.from_state(r) for r in rows]
            entry = apply(Entry.from_state(ledger.get(ticker)), fills)
            entry = balance(
                entry,
                quantity if is_open else _ZERO,
                total_cost=total_cost if is_open and quantity > 0 else None,
                cost_price=_stored(info, "last_cost_price"),
                unit_price=_stored(info, "last_unit_price"),
                since=iso_date(pos.get("createdAt")) if is_open else None,
                today=today,
            )
            ledger[ticker] = entry.to_state()
            pending.pop(ticker, None)
            combined = [_fill_trade(account_id, f) for f in fills] + balancing_trades(
                entry, account_id, ticker)
            trades = combined or None

        name = (info.get("name") or ticker)[:255]
        record: dict = {
            "external_id": f"t212:{account_id}:{ticker}",
            "name": name,
            "currency": currency,
            "ticker": short_symbol(ticker, info.get("short")),
            "trades": trades,
        }
        kind = info.get("type")
        if kind is not None:
            record["type"] = kind
        if info.get("isin"):
            record["isin"] = info["isin"]

        if is_open:
            record["current_value"] = number(value)
            record["quantity"] = number(quantity)
            if quantity > 0:
                record["unit_price"] = number(max(value / quantity, _ZERO))
            record["purchase_price"] = number(max(cost, _ZERO))
            created = iso_date(pos.get("createdAt"))
            if created is not None:
                record["purchase_date"] = created.isoformat()
            record["metadata"] = {
                "t212_ticker": ticker,
                "instrument_currency": str(pos["instrument"].get("currency") or ""),
                "average_price_paid": number(_dec(pos.get("averagePricePaid"))),
                "current_price": number(_dec(pos.get("currentPrice"))),
                "quantity_in_pies": number(_dec(pos.get("quantityInPies"))),
            }
            closed.pop(ticker, None)
        else:
            record["current_value"] = "0"
            record["quantity"] = "0"
            record["metadata"] = {"t212_ticker": ticker}
            closed[ticker] = True
        holdings.append(record)
    return holdings
