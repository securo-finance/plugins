"""Walk Trading 212 history endpoints (newest-first) with a resumable cursor."""

from typing import Any

from . import log
from .client import API_PREFIX
from .errors import OutOfTime, RateLimited

ENDPOINTS = {
    "transactions": "/equity/history/transactions",
    "dividends": "/equity/history/dividends",
    "orders": "/equity/history/orders",
}
PAGE_LIMIT = 50


def item_key(endpoint: str, item: dict) -> str | None:
    if endpoint == "orders":
        fill = item.get("fill")
        if fill:
            return str(fill.get("id"))
        return "o" + str((item.get("order") or {}).get("id"))
    ref = item.get("reference")
    return None if ref is None else str(ref)


def _seen(endpoint: str, key: str | None, newest: str | None) -> bool:
    if key is None or newest is None:
        return False
    if key == newest:
        return True
    if endpoint == "orders" and key.isdigit() and newest.isdigit():
        return int(key) <= int(newest)
    return False


def _same_page(a: str, b: str) -> bool:
    def full(path: str) -> str:
        return path if path.startswith(API_PREFIX) else API_PREFIX + path

    return full(a) == full(b)


def advance(client: Any, endpoint: str, hstate: dict) -> tuple[list[dict], dict, bool]:
    h = dict(hstate)
    items: list[dict] = []
    path = h.get("next") or f"{ENDPOINTS[endpoint]}?limit={PAGE_LIMIT}"
    while True:
        try:
            page = client.get(path)
        except (RateLimited, OutOfTime):
            h["next"] = path
            return items, h, False
        page_items = page.get("items") or []
        if h.get("head") is None and page_items:
            h["head"] = item_key(endpoint, page_items[0])
        reached = False
        for item in page_items:
            if h.get("phase") == "incremental" and _seen(endpoint, item_key(endpoint, item), h.get("newest")):
                reached = True
                break
            items.append(item)
        following = page.get("nextPagePath")
        if following and _same_page(following, path):
            # Following it would fetch the same page forever, this sync and every next one.
            log.warning("a history page pointed to itself")
            following = None
        if reached or not following:
            h.update(phase="incremental", next=None, newest=h.pop("head", None) or h.get("newest"))
            return items, h, True
        path = following
        h["next"] = following
