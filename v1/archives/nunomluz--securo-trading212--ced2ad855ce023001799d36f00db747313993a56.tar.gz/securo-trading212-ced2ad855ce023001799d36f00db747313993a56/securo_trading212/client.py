"""Read-only HTTP client for the Trading 212 API.

Error messages are fixed text: they never include credentials, URLs or
response bodies.
"""

import base64
import http.client
import json
import re
import time
import urllib.error
import urllib.request
from collections.abc import Callable
from decimal import Decimal
from typing import Any

from .errors import NeedsAuth, OutOfTime, RateLimited, Transient

HOSTS = {"live": "live.trading212.com", "demo": "demo.trading212.com"}
API_PREFIX = "/api/v0"
BUDGET_SECONDS = 40
HTTP_TIMEOUT = 15
MAX_RESPONSE_BYTES = 32 * 1024 * 1024
_MAX_CREDENTIAL = 512
_ERROR_BODY_BYTES = 4096

# (url, headers, timeout in seconds) -> (status, lower-cased headers, body)
Http = Callable[[str, dict[str, str], float], tuple[int, dict[str, str], bytes]]

_SCOPE = re.compile(r"Scope\(\s*([A-Za-z:_]+)\s*\)")


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


_opener = urllib.request.build_opener(_NoRedirect)


def urllib_get(url: str, headers: dict[str, str],
               timeout: float = HTTP_TIMEOUT) -> tuple[int, dict[str, str], bytes]:
    """GET without following redirects. Raises OSError on transport failure."""
    request = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with _opener.open(request, timeout=timeout) as resp:
            body = resp.read(MAX_RESPONSE_BYTES + 1)
            if len(body) > MAX_RESPONSE_BYTES:
                raise Transient("Trading 212 returned a response that is too large.")
            return resp.status, {k.lower(): v for k, v in resp.headers.items()}, body
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read(_ERROR_BODY_BYTES)
        except OSError:
            body = b""
        return exc.code, {k.lower(): v for k, v in exc.headers.items()}, body


class Client:
    def __init__(
        self,
        *,
        api_key: str,
        api_secret: str,
        environment: str | None,
        http: Http = urllib_get,
        clock: Callable[[], float] = time.monotonic,
        wall: Callable[[], float] = time.time,
        sleep: Callable[[float], None] = time.sleep,
        budget: float = BUDGET_SECONDS,
    ) -> None:
        env = (environment or "").strip().lower() or "live"
        if env not in HOSTS:
            raise NeedsAuth("The Trading 212 environment must be live or demo.", code="environment_invalid")
        key = (api_key or "").strip()
        secret = (api_secret or "").strip()
        if not key or not secret:
            raise NeedsAuth("Enter both the Trading 212 API key and secret.")
        if len(key) > _MAX_CREDENTIAL or len(secret) > _MAX_CREDENTIAL:
            raise NeedsAuth("The Trading 212 API key or secret is too long.")
        token = base64.b64encode(f"{key}:{secret}".encode()).decode()
        self._headers = {"Authorization": f"Basic {token}", "Accept": "application/json"}
        self._host = HOSTS[env]
        self._http = http
        self._clock = clock
        self._wall = wall
        self._sleep = sleep
        self._deadline = clock() + budget
        self._blocked: dict[str, float] = {}

    def remaining(self) -> float:
        return self._deadline - self._clock()

    def get(self, path: str) -> Any:
        if (
            not path.startswith("/")
            or path.startswith("//")
            or "://" in path
            or "\\" in path
            or any(ord(ch) <= 0x20 or ord(ch) == 0x7F for ch in path)
        ):
            raise Transient("Trading 212 returned an unexpected page link.")
        if not path.startswith(API_PREFIX):
            path = API_PREFIX + path
        url = f"https://{self._host}{path}"
        bare = path.split("?", 1)[0]

        self._wait_if_blocked(bare)
        status, headers, body = self._request(url)
        if status == 429:
            reset = self._parse_reset(headers)
            self._blocked[bare] = reset if reset is not None else self._wall() + 60
            self._wait_if_blocked(bare)
            status, headers, body = self._request(url)
            if status == 429:
                raise RateLimited("Trading 212 rate limit reached.")
        self._track(bare, headers)
        return self._handle(status, body)

    def _request(self, url: str) -> tuple[int, dict[str, str], bytes]:
        remaining = self.remaining()
        if remaining <= 0:
            raise OutOfTime("The sync time budget ran out.")
        # A slow request must not run past the budget (Securo kills the call at 60 s).
        timeout = min(HTTP_TIMEOUT, max(remaining, 1))
        try:
            return self._http(url, dict(self._headers), timeout)
        except (OSError, http.client.HTTPException) as exc:
            raise Transient(f"Couldn't reach Trading 212 ({type(exc).__name__}).") from None

    def _wait_if_blocked(self, bare: str) -> None:
        reset = self._blocked.get(bare)
        if reset is None:
            return
        wait = reset - self._wall()
        if wait > self.remaining() - 2:
            raise RateLimited("Trading 212 rate limit reached.")
        del self._blocked[bare]
        self._sleep(max(wait, 0) + 0.5)

    @staticmethod
    def _parse_reset(headers: dict[str, str]) -> float | None:
        try:
            return float(headers["x-ratelimit-reset"])
        except (KeyError, ValueError):
            return None

    def _track(self, bare: str, headers: dict[str, str]) -> None:
        if headers.get("x-ratelimit-remaining") == "0":
            reset = self._parse_reset(headers)
            if reset is not None:
                self._blocked[bare] = reset

    @staticmethod
    def _handle(status: int, body: bytes) -> Any:
        if status == 401:
            raise NeedsAuth("Trading 212 rejected the API key or secret.")
        if status == 403:
            match = _SCOPE.search(body[:2048].decode("utf-8", "replace"))
            if match:
                raise NeedsAuth(
                    f'The API key is missing the "{match.group(1)}" permission. '
                    "Edit the key in Trading 212 and enable it.",
                    code="permission_missing",
                )
            raise NeedsAuth(
                "The API key isn't allowed to read this. Edit the key's permissions in Trading 212.",
                code="permission_missing",
            )
        if status != 200:
            raise Transient(f"Trading 212 answered HTTP {status}.")
        try:
            return json.loads(body, parse_float=Decimal)
        except ValueError:
            raise Transient("Trading 212 returned an unreadable response.") from None
