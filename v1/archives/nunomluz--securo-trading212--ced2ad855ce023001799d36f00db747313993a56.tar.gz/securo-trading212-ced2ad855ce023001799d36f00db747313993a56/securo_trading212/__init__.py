"""Securo plugin that syncs Trading 212 accounts read-only."""
