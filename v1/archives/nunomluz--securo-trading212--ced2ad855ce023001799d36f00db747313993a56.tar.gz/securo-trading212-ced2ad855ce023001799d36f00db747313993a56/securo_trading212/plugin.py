"""Securo entry point: sync Trading 212 accounts (read-only)."""

import copy
import time
from collections.abc import Callable
from datetime import date, datetime, timezone
from decimal import Decimal

from . import log
from .client import Client, Http, urllib_get
from .errors import OutOfTime, RateLimited, Transient
from .history import advance
from .mapping import (
    asset_type,
    cash_from_dividend,
    cash_from_transaction,
    fill_from_order,
    instrument_info,
)
from .payload import CONTRACT, account_record, build_holdings

INSTRUMENTS_MAX_AGE = 24 * 3600


def _remember(instruments: dict, instrument: dict) -> None:
    ticker = instrument.get("ticker")
    if not ticker:
        return
    info = instruments.setdefault(ticker, {})
    found = instrument_info(instrument)
    info["name"] = found["name"]
    info["isin"] = found["isin"]


class Trading212:
    def __init__(
        self,
        *,
        http: Http | None = None,
        clock: Callable[[], float] | None = None,
        wall: Callable[[], float] | None = None,
        sleep: Callable[[float], None] | None = None,
        today: Callable[[], date] | None = None,
    ) -> None:
        self._http = http
        self._clock = clock
        self._wall = wall or time.time
        self._sleep = sleep
        self._today = today

    def _client(self, context) -> Client:
        kwargs: dict = {"http": self._http or urllib_get, "wall": self._wall}
        if self._clock is not None:
            kwargs["clock"] = self._clock
        if self._sleep is not None:
            kwargs["sleep"] = self._sleep
        secrets = getattr(context, "secrets", None) or {}
        config = getattr(context, "config", None) or {}
        return Client(
            api_key=secrets.get("api_key") or "",
            api_secret=secrets.get("api_secret") or "",
            environment=config.get("environment"),
            **kwargs,
        )

    def sync(self, params: dict, context) -> dict:
        log.reset()
        original = params.get("state")
        state = copy.deepcopy(original) if original else {}
        client = self._client(context)

        try:
            summary = client.get("/equity/account/summary")
            account_id = str(summary["id"])
            currency = summary["currency"]
            if state.get("account_id") and state["account_id"] != account_id:
                log.warning("this key belongs to a different account; starting over")
                state = {}
            state["account_id"] = account_id
            positions = client.get("/equity/positions")
        except (RateLimited, OutOfTime):
            return {"state": original if original is not None else {}, "data": None}

        instruments = state.setdefault("instruments", {})
        for pos in positions:
            if isinstance(pos.get("instrument"), dict):
                _remember(instruments, pos["instrument"])

        history = state.setdefault("history", {})
        pending = state.setdefault("pending", {})
        seen = set(state.get("seen_fills") or [])
        seen_list = list(state.get("seen_fills") or [])
        cash = []
        orders_done = False
        # Orders first: holdings depend on that walk finishing within the budget.
        for endpoint in ("orders", "transactions", "dividends"):
            items, hstate, done = advance(client, endpoint, history.get(endpoint, {}))
            history[endpoint] = hstate
            if endpoint == "transactions":
                cash += [c for c in (cash_from_transaction(i, account_id) for i in items) if c]
            elif endpoint == "dividends":
                cash += [c for c in (cash_from_dividend(i, account_id) for i in items) if c]
            else:
                for item in items:
                    fill = fill_from_order(item, currency)
                    if fill is None or fill.id in seen:
                        continue
                    seen.add(fill.id)
                    seen_list.append(fill.id)
                    pending.setdefault(fill.ticker, []).append(fill.to_state())
                    order_instrument = (item.get("order") or {}).get("instrument")
                    if isinstance(order_instrument, dict):
                        _remember(instruments, order_instrument)
                orders_done = done
                if done:
                    state["orders_complete"] = True
        state["seen_fills"] = seen_list

        self._fetch_types(client, state, positions)

        data: dict = {"contract": CONTRACT, "accounts": [account_record(summary, cash)]}
        if state.get("orders_complete") and orders_done:
            positions = self._stable_positions(client, positions)
        else:
            positions = None
        if positions is not None:
            today = self._today() if self._today else datetime.fromtimestamp(
                self._wall(), timezone.utc).date()
            data["holdings"] = build_holdings(
                account_id=account_id, currency=currency, positions=positions,
                state=state, today=today)
        return {"state": state, "data": data}

    @staticmethod
    def _stable_positions(client: Client, first: list[dict]) -> list[dict] | None:
        try:
            second = client.get("/equity/positions")
        except (RateLimited, OutOfTime):
            return None

        def quantities(rows: list[dict]) -> dict:
            out = {}
            for p in rows:
                ticker = (p.get("instrument") or {}).get("ticker")
                if ticker:
                    out[ticker] = Decimal(str(p.get("quantity") or 0))
            return out

        if quantities(first) != quantities(second):
            log.warning("positions changed during the sync; holdings wait for the next one")
            return None
        return second

    def _fetch_types(self, client: Client, state: dict, positions: list[dict]) -> None:
        instruments = state["instruments"]
        wanted = {(p.get("instrument") or {}).get("ticker") for p in positions}
        wanted |= set(state["pending"]) | set(state.get("ledger") or {}) | set(state.get("closed") or {})
        wanted.discard(None)
        missing = [t for t in wanted if not (instruments.get(t) or {}).get("type")]
        for ticker in missing:
            instruments.setdefault(ticker, {})
        now = self._wall()
        stamp = state.get("instruments_at")
        if not missing or (stamp is not None and now - stamp < INSTRUMENTS_MAX_AGE):
            return
        try:
            metadata = client.get("/equity/metadata/instruments")
        except (RateLimited, OutOfTime, Transient):
            # Types are optional: a failed lookup is retried on a later sync.
            return
        for meta in metadata:
            ticker = meta.get("ticker")
            if ticker not in instruments:
                continue
            kind = asset_type(meta.get("type"))
            if kind:
                instruments[ticker]["type"] = kind
            if meta.get("shortName"):
                instruments[ticker]["short"] = meta["shortName"]
        state["instruments_at"] = now


plugin = Trading212()
