"""Map Trading 212 history items to Securo records."""

import re
from dataclasses import dataclass
from datetime import date, datetime, timezone
from decimal import Decimal

from . import log
from .numbers import number, parse_decimal

PAYEE = "Trading 212"
_CURRENCY = re.compile(r"^[A-Z]{3}$")
_SKIPPED = "skipped a cash item without a reference, date, amount or currency"
_TYPE_CHARS = re.compile(r"[^A-Z0-9_]")

# transaction type -> (direction, description); direction None means "follow the sign"
_TRANSACTION_TYPES: dict[str, tuple[str | None, str]] = {
    "DEPOSIT": ("credit", "Deposit"),
    "INTEREST_ON_FREE_CASH": ("credit", "Interest on cash"),
    "LENDING_INTEREST": ("credit", "Share lending interest"),
    "WITHDRAW": ("debit", "Withdrawal"),
    "FEE": ("debit", "Fee"),
    "TRANSFER": (None, "Transfer"),
}


@dataclass(frozen=True)
class CashTxn:
    external_id: str
    description: str
    amount: Decimal  # always > 0
    date: date
    type: str  # "credit" or "debit"
    currency: str
    payee: str


def iso_date(value: object) -> date | None:
    """Date part of an ISO date-time, converted to UTC first when it has an offset."""
    if not isinstance(value, str):
        return None
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return None
    if parsed.tzinfo is not None:
        parsed = parsed.astimezone(timezone.utc)
    return parsed.date()


def _amount(value: object) -> Decimal | None:
    if isinstance(value, float):
        value = str(value)
    return parse_decimal(value)


def _currency(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    code = value.upper()
    return code if _CURRENCY.match(code) else None


def _text(value: object) -> str | None:
    if isinstance(value, int) and not isinstance(value, bool):
        return str(value)
    return value.strip() if isinstance(value, str) and value.strip() else None


def _build(item: dict, account_id: str, kind: str, when: object, description: str,
           payee: str, direction: str | None) -> CashTxn | None:
    reference = _text(item.get("reference"))
    day = iso_date(when)
    amount = _amount(item.get("amount"))
    currency = _currency(item.get("currency"))
    if reference is None or day is None or amount is None or currency is None or amount == 0:
        log.warning(_SKIPPED)
        return None
    return CashTxn(
        external_id=f"t212:{account_id}:{kind}:{reference}",
        description=description,
        amount=abs(amount),
        date=day,
        type=direction or ("credit" if amount > 0 else "debit"),
        currency=currency,
        payee=payee,
    )


def cash_from_transaction(item: dict, account_id: str) -> CashTxn | None:
    kind = item.get("type")
    direction, description = _TRANSACTION_TYPES.get(kind, (None, "Trading 212 cash movement"))
    if kind not in _TRANSACTION_TYPES:
        log.unknown("transaction type", kind)
    return _build(item, account_id, "txn", item.get("dateTime"), description, PAYEE, direction)


def cash_from_dividend(item: dict, account_id: str) -> CashTxn | None:
    instrument = item.get("instrument")
    name = _text(instrument.get("name")) if isinstance(instrument, dict) else None
    label = name or _text(item.get("ticker")) or "Unknown"
    kind = _TYPE_CHARS.sub("", str(item.get("type") or "").upper())[:40]
    description = f"Dividend: {label} ({kind})" if kind else f"Dividend: {label}"
    return _build(item, account_id, "div", item.get("paidOn"),
                  description[:500], label[:200], None)


_ISIN = re.compile(r"^[A-Z]{2}[A-Z0-9]{9}[0-9]$")
_KNOWN_FILL_TYPES = {
    "STOCK_SPLIT", "STOCK_DISTRIBUTION", "FOP", "FOP_CORRECTION", "CUSTOM_STOCK_DISTRIBUTION",
    "EQUITY_RIGHTS", "SCRIP_STOCK_DIVIDENDS", "STOCK_DIVIDENDS", "STOCK_ACQUISITION",
    "CASH_AND_STOCK_ACQUISITION", "SPIN_OFF",
}
_ASSET_TYPES = {"STOCK": "stock", "ETF": "etf", "CRYPTO": "crypto", "CRYPTOCURRENCY": "crypto"}


@dataclass(frozen=True)
class Fill:
    id: str
    ticker: str
    date: date
    kind: str  # "buy" or "sell"
    quantity: Decimal
    price: Decimal
    fee: Decimal

    def to_state(self) -> list:
        return [self.id, self.ticker, self.date.isoformat(), self.kind,
                number(self.quantity), number(self.price), number(self.fee)]

    @classmethod
    def from_state(cls, row: list) -> "Fill":
        return cls(str(row[0]), row[1], date.fromisoformat(row[2]), row[3],
                   Decimal(row[4]), Decimal(row[5]), Decimal(row[6]))


def instrument_info(instrument: dict) -> dict:
    name = _text(instrument.get("name")) or _text(instrument.get("ticker")) or "Unknown"
    isin = instrument.get("isin")
    return {"name": name, "isin": isin if isinstance(isin, str) and _ISIN.match(isin) else None}


def asset_type(t212_type: str | None) -> str | None:
    if not t212_type:
        return None
    return _ASSET_TYPES.get(t212_type.upper(), "investment")


def short_symbol(ticker: str, short_name: str | None) -> str:
    return (short_name or ticker.split("_", 1)[0])[:32]


def _price_and_fee(fill: dict, quantity: Decimal, kind: str, instrument_ccy: str | None,
                   account_ccy: str) -> tuple[Decimal, Decimal] | None:
    """Account-currency price per unit and fee, or None when they can't be known."""
    wallet = fill.get("walletImpact") or {}
    raw_price = _amount(fill.get("price")) or Decimal(0)
    net = _amount(wallet.get("netValue"))
    fx = _amount(wallet.get("fxRate"))
    # Fees: taxes in the account currency count as-is; others go through fx (direction found below).
    taxes = [(_amount(t.get("quantity")) or Decimal(0), (t.get("currency") or "").upper())
             for t in wallet.get("taxes") or []]
    same = [abs(q) for q, c in taxes if c in ("", account_ccy)]
    other = [abs(q) for q, c in taxes if c not in ("", account_ccy)]
    if net is None or net == 0:
        if instrument_ccy != account_ccy:
            # The price is in another (or an unknown) currency with no usable rate;
            # the opening buy covers the units at the position's residual cost.
            log.warning("a trade had no net value and a foreign price; skipped")
            return None
        log.warning("a trade had no net value; used its instrument price")
        return raw_price, sum(same, Decimal(0))
    gross_per_unit = abs(net) / quantity
    # Candidate conversions of the instrument price into the account currency.
    candidates = {"same": raw_price}
    if fx and fx > 0 and instrument_ccy and instrument_ccy != account_ccy:
        candidates = {"mul": raw_price * fx, "div": raw_price / fx}

    def convert(q: Decimal, key: str) -> Decimal:
        return q * fx if key == "mul" else q / fx if key == "div" else q

    fee_by = {k: sum(same, Decimal(0)) + sum((convert(q, k) for q in other), Decimal(0))
              for k in candidates}
    best = None  # (relative error, key, net_includes_fees)
    for key, price in candidates.items():
        if price <= 0:
            continue
        for includes in (True, False):
            fee = fee_by[key]
            expected = price * quantity + (fee if kind == "buy" else -fee) if includes else price * quantity
            error = abs(abs(net) - expected) / expected if expected else None
            if error is not None and (best is None or error < best[0]):
                best = (error, key, includes)
    if best is None or best[0] > Decimal("0.02"):
        log.warning("a trade's price didn't match its net value; used net value per unit without fees")
        return gross_per_unit, Decimal(0)
    _, key, includes = best
    fee = fee_by[key]
    if not includes:
        return gross_per_unit, fee
    per_unit = (abs(net) - fee) / quantity if kind == "buy" else (abs(net) + fee) / quantity
    return max(per_unit, Decimal(0)), fee


def fill_from_order(item: dict, account_currency: str) -> Fill | None:
    fill = item.get("fill")
    if not isinstance(fill, dict):
        return None
    fill_type = fill.get("type")
    if fill_type != "TRADE":
        if fill_type not in _KNOWN_FILL_TYPES:
            log.unknown("fill type", fill_type)
        return None
    order = item.get("order") if isinstance(item.get("order"), dict) else {}
    side = order.get("side")
    kind = {"BUY": "buy", "SELL": "sell"}.get(side)
    quantity = _amount(fill.get("quantity"))
    quantity = abs(quantity) if quantity is not None else Decimal(0)
    instrument = order.get("instrument") if isinstance(order.get("instrument"), dict) else {}
    ticker = _text(order.get("ticker")) or _text(instrument.get("ticker"))
    day = iso_date(fill.get("filledAt"))
    fill_id = fill.get("id")
    if kind is None or quantity <= 0 or ticker is None or day is None or fill_id is None:
        return None
    priced = _price_and_fee(fill, quantity, kind, _currency(instrument.get("currency")),
                            account_currency.upper())
    if priced is None:
        return None
    price, fee = priced
    return Fill(str(fill_id), ticker, day, kind, quantity, price, fee)
