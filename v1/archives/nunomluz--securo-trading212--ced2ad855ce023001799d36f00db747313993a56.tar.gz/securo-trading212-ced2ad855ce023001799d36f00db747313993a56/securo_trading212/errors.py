"""Exception types used by the plugin."""

HELP_URL = "https://helpcentre.trading212.com/hc/en-us/articles/14584770928157-Trading-212-API-key"


class NeedsAuth(Exception):
    """Credentials are missing or rejected. The user must act."""

    def __init__(self, message: str, *, code: str = "credentials_invalid") -> None:
        super().__init__(f"{message} Help: {HELP_URL}")
        self.code = code


class Transient(Exception):
    """A retryable failure."""


class RateLimited(Exception):
    """Internal signal: the API rate limit was hit. Never escapes sync."""


class OutOfTime(Exception):
    """Internal signal: the sync time budget ran out. Never escapes sync."""
