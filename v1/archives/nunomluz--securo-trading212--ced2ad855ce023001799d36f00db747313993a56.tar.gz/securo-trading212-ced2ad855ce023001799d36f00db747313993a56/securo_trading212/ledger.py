"""Running quantity per instrument, plus the balancing trades Securo needs."""

from dataclasses import dataclass, field, replace
from datetime import date, timedelta
from decimal import Decimal

from .mapping import Fill
from .numbers import number

# A shortfall or surplus at or below this is rounding, not a missing trade.
# Securo accepts a replay within max(0.0001, 1e-6 x largest lot) of the position.
TOLERANCE = Decimal("0.00001")
# A balancing trade Securo already stored can't be removed by leaving it out, so
# one no longer needed is resent at this quantity (the smallest Securo keeps).
FLOOR = Decimal("0.000001")
# Largest price that fits Securo's trade price column (12 digits before the point).
_MAX_PRICE = Decimal("999999999999")
_ZERO = Decimal(0)


def _zero() -> Decimal:
    return Decimal(0)


@dataclass
class Entry:
    net: Decimal = field(default_factory=_zero)
    low: Decimal = field(default_factory=_zero)
    first: date | None = None
    open: Decimal = field(default_factory=_zero)
    open_price: Decimal = field(default_factory=_zero)
    adjust: Decimal = field(default_factory=_zero)
    adjust_date: date | None = None
    adjust_price: Decimal = field(default_factory=_zero)
    open_sent: bool = False
    adjust_sent: bool = False
    # Average-cost basis of the held fill lots, the net - low units bought by fills
    # and not yet sold (buys add qty x price + fee).
    cost: Decimal = field(default_factory=_zero)
    sold: Decimal = field(default_factory=_zero)
    sold_value: Decimal = field(default_factory=_zero)
    # Value of the sold units that took the running quantity below its lowest point.
    dip_value: Decimal = field(default_factory=_zero)
    # Net quantity change per fill date (ISO date -> amount): low is replayed from it.
    days: dict[str, Decimal] = field(default_factory=dict)
    # A floor on low carried over from state written before days were kept.
    bound: Decimal = field(default_factory=_zero)

    def to_state(self) -> dict:
        return {
            "net": number(self.net),
            "low": number(self.low),
            "first": self.first.isoformat() if self.first else None,
            "open": number(self.open),
            "open_price": number(self.open_price),
            "adjust": number(self.adjust),
            "adjust_date": self.adjust_date.isoformat() if self.adjust_date else None,
            "adjust_price": number(self.adjust_price),
            "open_sent": self.open_sent,
            "adjust_sent": self.adjust_sent,
            "cost": number(self.cost),
            "sold": number(self.sold),
            "sold_value": number(self.sold_value),
            "dip_value": number(self.dip_value),
            "days": {day: number(amount) for day, amount in sorted(self.days.items())},
            "bound": number(self.bound),
        }

    @classmethod
    def from_state(cls, d: dict | None) -> "Entry":
        if not d:
            return cls()

        def dec(key: str) -> Decimal:
            return Decimal(str(d.get(key) or 0))

        def day(key: str) -> date | None:
            value = d.get(key)
            return date.fromisoformat(value) if value else None

        def sent(key: str, quantity: Decimal) -> bool:
            # State written before the flag existed: a trade with a quantity was sent.
            return bool(d[key]) if key in d else quantity > 0

        opening, adjust = dec("open"), dec("adjust")
        if "days" in d:
            days = {str(k): Decimal(str(v)) for k, v in (d.get("days") or {}).items()}
            bound = dec("bound")
        else:
            # Written before days were kept: the net sits on the first date, and the
            # low it had stays a floor (it can't be replayed any more).
            net, first = dec("net"), d.get("first")
            days = {first: net} if net != 0 and first else {}
            bound = min(dec("low"), _ZERO)
        return cls(
            net=dec("net"),
            low=dec("low"),
            first=day("first"),
            open=opening,
            open_price=dec("open_price"),
            adjust=adjust,
            adjust_date=day("adjust_date"),
            adjust_price=dec("adjust_price"),
            open_sent=sent("open_sent", opening),
            adjust_sent=sent("adjust_sent", adjust),
            cost=dec("cost"),
            sold=dec("sold"),
            sold_value=dec("sold_value"),
            dip_value=dec("dip_value"),
            days=days,
            bound=bound,
        )


def apply(entry: Entry, fills: list[Fill]) -> Entry:
    """Replay fills on top of entry, tracking the lowest running quantity and held cost.

    low is the lowest quantity Securo's replay reaches, recomputed from the net
    change per day, so a fill that arrives late, dated before others, still lands
    in its place. Within a day Securo replays buys first, so a day's lowest point
    is its end-of-day total. Cost, sold and dip value follow the fills in the
    order they are applied (exact for fills that arrive in date order).

    A sell dated on or before the adjustment sell's date lowers the replay at that
    date, so it clears the date and balance moves the adjustment sell to today.
    """
    e = replace(entry)
    e.days = dict(entry.days)
    sold_before, sold_value_before = e.sold, e.sold_value
    for fill in sorted(fills, key=lambda f: (f.date, f.kind != "buy", f.id)):
        price = max(fill.price, _ZERO)
        if fill.kind == "buy":
            e.cost += fill.quantity * price + max(fill.fee, _ZERO)
            e.net += fill.quantity
        else:
            held = e.net - e.low
            if held > 0:
                e.cost -= e.cost * min(fill.quantity, held) / held
            e.sold += fill.quantity
            e.sold_value += fill.quantity * price
            e.net -= fill.quantity
            if e.adjust_date is not None and fill.date <= e.adjust_date:
                e.adjust_date = None
            if e.net < e.low:
                e.dip_value += (e.low - e.net) * price
                e.low = e.net
        day = fill.date.isoformat()
        change = e.days.get(day, _ZERO) + (fill.quantity if fill.kind == "buy" else -fill.quantity)
        if change:
            e.days[day] = change
        else:
            e.days.pop(day, None)
        if e.first is None or fill.date < e.first:
            e.first = fill.date

    exact = _replay_low(e.days, e.bound)
    if exact < e.low:
        # Late sells deepened the dip: value the extra units at this call's sell price.
        sold = e.sold - sold_before
        if sold > 0:
            e.dip_value += (e.low - exact) * (e.sold_value - sold_value_before) / sold
    elif exact > e.low:
        # Late buys filled part of the dip back in.
        e.dip_value = e.dip_value * exact / e.low if exact < 0 else _ZERO
    e.low = exact
    return e


def _replay_low(days: dict[str, Decimal], bound: Decimal) -> Decimal:
    """Lowest end-of-day running quantity, at most 0 (nothing held before the first fill)."""
    running = lowest = _ZERO
    for day in sorted(days):
        running += days[day]
        lowest = min(lowest, running)
    return min(lowest, bound)


def _needed(quantity: Decimal) -> Decimal:
    return quantity if quantity > TOLERANCE else _ZERO


def balance(
    entry: Entry,
    target: Decimal,
    *,
    today: date,
    total_cost: Decimal | None = None,
    cost_price: Decimal | None = None,
    unit_price: Decimal | None = None,
    since: date | None = None,
) -> Entry:
    """Size the opening buy and adjustment sell afresh so the trades replay to target.

    total_cost is the open position's cost basis; cost_price and unit_price are the
    last known cost and value per unit (None when never seen). since is when the
    position was opened, used to date an opening buy that has no fills to precede.

    A balancing trade sent before can't be deleted from Securo, so one no longer
    needed is kept at FLOOR instead of dropped. An opening buy is repriced only
    when its quantity changes. An adjustment sell keeps its date and price while
    its quantity is unchanged (or floored); any other change moves it to today,
    the one date where it always replays without going below zero.
    """
    e = replace(entry)
    # The opening has two parts: units sold before any were bought (the dip) and
    # held units no fill explains (the shortfall). Together max(-low, target - net).
    dip = max(-e.low, _ZERO)
    shortfall = max(target - (e.net - e.low), _ZERO)
    need_open = _needed(dip + shortfall)
    opening = need_open if need_open > 0 else (FLOOR if e.open_sent else _ZERO)
    need_adjust = _needed(e.net + opening - target)
    adjust = need_adjust if need_adjust > 0 else (FLOOR if e.adjust_sent else _ZERO)

    if need_open > 0 and abs(need_open - entry.open) > TOLERANCE:
        e.open_price = _opening_price(e, need_open, dip, shortfall, total_cost, cost_price)
    if need_adjust > 0 and (e.adjust_date is None or abs(need_adjust - entry.adjust) > TOLERANCE):
        e.adjust_date = today
        e.adjust_price = _adjust_price(e, unit_price)
    elif adjust > 0 and e.adjust_date is None:
        e.adjust_date = today  # a floored adjustment sell whose date was cleared

    e.open, e.adjust = opening, adjust
    e.open_sent = e.open_sent or opening > 0
    e.adjust_sent = e.adjust_sent or adjust > 0
    if opening > 0 and e.first is None:
        e.first = since if since is not None and since < today else today
    return e


def _opening_price(e: Entry, opening: Decimal, dip: Decimal, shortfall: Decimal,
                   total_cost: Decimal | None, cost_price: Decimal | None) -> Decimal:
    """The quantity-weighted price of the opening's dip and shortfall parts."""
    value = _ZERO
    if shortfall > TOLERANCE:
        if total_cost is not None:
            # Held units the fills don't explain (transfers in, splits, history out of
            # reach) carry whatever cost the held fill lots don't account for.
            value += max(total_cost - e.cost, _ZERO)
        elif cost_price is not None:
            value += shortfall * max(cost_price, _ZERO)
    if dip > 0:
        if cost_price is not None:
            value += dip * max(cost_price, _ZERO)
        else:
            # Price units sold before any were bought like those sells: no made-up gain.
            value += max(e.dip_value, _ZERO)
    return max(value / opening, _ZERO)


def _adjust_price(e: Entry, unit_price: Decimal | None) -> Decimal:
    if unit_price is not None:
        return max(unit_price, _ZERO)
    if e.sold > 0:
        return max(e.sold_value / e.sold, _ZERO)
    return _ZERO


def _price(value: Decimal) -> str:
    return number(min(max(value, _ZERO), _MAX_PRICE))


def balancing_trades(entry: Entry, account_id: str, ticker: str) -> list[dict]:
    trades: list[dict] = []
    if entry.open > 0 and entry.first is not None:
        trades.append(
            {
                "external_id": f"t212:{account_id}:opening:{ticker}",
                "kind": "buy",
                "date": (entry.first - timedelta(days=1)).isoformat(),
                "quantity": number(entry.open),
                "price": _price(entry.open_price),
                "fee": "0",
            }
        )
    if entry.adjust > 0 and entry.adjust_date is not None:
        trades.append(
            {
                "external_id": f"t212:{account_id}:adjust:{ticker}",
                "kind": "sell",
                "date": entry.adjust_date.isoformat(),
                "quantity": number(entry.adjust),
                "price": _price(entry.adjust_price),
                "fee": "0",
            }
        )
    return trades
