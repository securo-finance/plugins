import copy
import json
from types import SimpleNamespace

import pytest

from securo_trading212.errors import NeedsAuth
from securo_trading212.plugin import Trading212
from tests.factories import (
    FakeHttp, dividend, instrument_meta, ok, order, page, position, summary, transaction,
)
from tests.test_client import WALL0

S = "/api/v0/equity/account/summary"
POS = "/api/v0/equity/positions"
T = "/api/v0/equity/history/transactions"
D = "/api/v0/equity/history/dividends"
O = "/api/v0/equity/history/orders"
META = "/api/v0/equity/metadata/instruments"
FAR = str(WALL0 + 1000)


def ctx(environment=None):
    return SimpleNamespace(
        secrets={"api_key": "test-key", "api_secret": "test-secret"},
        config={"environment": environment} if environment else {},
    )


def routes(orders=None, **over):
    base = {
        S: [ok(summary())],
        POS: [ok([position()])],
        T: [ok(page([transaction("t1")]))],
        D: [ok(page([dividend("d1")]))],
        O: [ok(page(orders if orders is not None else [order(1, quantity=2, price=100, net=-200)]))],
        META: [ok([instrument_meta("AAPL_US_EQ", "ETF", "AAPL")])],
    }
    base.update(over)
    return base


def run(rts, state=None, environment=None, http=None):
    now = [0.0]
    http = http or FakeHttp(rts)
    p = Trading212(http=http, clock=lambda: now[0], wall=lambda: WALL0, sleep=lambda s: None,
                   today=lambda: __import__("datetime").date(2024, 6, 1))
    return p.sync({"state": state}, ctx(environment)), http


def holding_trades(result):
    return result["data"]["holdings"][0]["trades"]


def test_first_sync_full_history():
    result, _ = run(routes())
    data = result["data"]
    assert data["contract"] == 1
    kinds = {t["description"] for t in data["accounts"][0]["transactions"]}
    assert "Deposit" in kinds and any(k.startswith("Dividend") for k in kinds)
    holding = data["holdings"][0]
    assert holding["external_id"] == "t212:10000001:AAPL_US_EQ"
    assert any(t["external_id"].endswith(":fill:1") for t in holding["trades"])
    assert result["state"]["orders_complete"] is True


def test_backfill_not_finished_leaves_holdings_out():
    rts = routes(orders=[order(5)])
    rts[O] = [ok(page([order(5)], f"{O}?cursor=2&limit=50"), remaining="0", reset=FAR)]
    result, _ = run(rts)
    assert "holdings" not in result["data"]
    assert result["data"]["accounts"]
    assert len(result["state"]["pending"]["AAPL_US_EQ"]) == 1
    assert not result["state"].get("orders_complete")


def test_second_sync_incremental():
    first, _ = run(routes())
    state = first["state"]
    rts = routes(orders=[order(2, quantity=1, price=100, net=-100), order(1, quantity=2, price=100, net=-200)],
                 **{POS: [ok([position(quantity=3, cost=300, value=450)])]})
    second, _ = run(rts, state=state)
    ids = [t["external_id"] for t in holding_trades(second)]
    assert ids == ["t212:10000001:fill:2"]


def test_duplicate_fill_skipped():
    first, _ = run(routes())
    state = copy.deepcopy(first["state"])
    state["history"]["orders"] = {}  # force re-walk
    state["orders_complete"] = False
    assert "1" in state["seen_fills"]
    second, _ = run(routes(), state=state)
    assert "AAPL_US_EQ" not in second["state"]["pending"]
    assert second["state"]["seen_fills"].count("1") == 1
    assert all(not t["external_id"].endswith(":fill:1")
               for t in (holding_trades(second) or []))


def test_account_switch_resets_state():
    state = {"account_id": "999", "seen_fills": ["77"], "orders_complete": True,
             "pending": {"X": [["77", "X", "2024-01-01", "buy", "1", "1", "0"]]}}
    result, _ = run(routes(), state=state)
    assert result["state"]["account_id"] == "10000001"
    assert "999" not in json.dumps(result)
    assert "77" not in result["state"]["seen_fills"]


def test_summary_rate_limited_returns_null_data():
    state = {"account_id": "10000001", "history": {}}
    original = copy.deepcopy(state)
    rts = routes(**{S: [ok(summary(), remaining="0", reset=FAR)]})
    rts[S] = [(429, {"x-ratelimit-reset": FAR}, {})]
    result, _ = run(rts, state=state)
    assert result["data"] is None
    assert result["state"] is state
    assert state == original


def test_needs_auth_propagates():
    with pytest.raises(NeedsAuth):
        run(routes(**{S: [(401, {}, {})]}))


def test_instruments_fetched_once_per_day():
    first, http = run(routes())
    assert first["state"]["instruments"]["AAPL_US_EQ"]["type"] == "etf"
    state = first["state"]
    rts = routes(orders=[order(2, ticker="MSFT_US_EQ", name="Microsoft")],
                 **{POS: [ok([position(), position(ticker="MSFT_US_EQ", name="Microsoft")])]})
    second, http2 = run(rts, state=state)
    metas = [c for c in http.calls + http2.calls if c[0].endswith("/metadata/instruments")]
    assert len(metas) == 1
    assert "type" not in second["state"]["instruments"]["MSFT_US_EQ"]


def test_demo_environment():
    result, http = run(routes(), environment="demo")
    assert http.calls and all("demo.trading212.com" in url for url, _ in http.calls)


def test_output_is_json_serialisable():
    result, _ = run(routes())
    json.dumps(result)


def test_no_secret_in_output(capsys):
    result, _ = run(routes())
    assert "test-secret" not in json.dumps(result)
    assert "test-secret" not in capsys.readouterr().err


def test_params_state_not_mutated():
    first, _ = run(routes())
    state = first["state"]
    snapshot = copy.deepcopy(state)
    run(routes(), state=state)
    assert state == snapshot


def test_orders_walk_stopped_early_leaves_holdings_out():
    first, _ = run(routes())
    rts = routes()
    rts[O] = [(429, {"x-ratelimit-reset": FAR}, {})]
    second, _ = run(rts, state=first["state"])
    assert "holdings" not in second["data"]
    assert second["data"]["accounts"]


def test_positions_changed_during_sync_leaves_holdings_out(capsys):
    rts = routes()
    rts[POS] = [ok([position(quantity=2)]), ok([position(quantity=3)])]
    result, _ = run(rts)
    assert "holdings" not in result["data"]
    assert len(result["state"]["pending"]["AAPL_US_EQ"]) == 1
    assert "positions changed" in capsys.readouterr().err


def test_positions_unchanged_sends_holdings():
    rts = routes()
    rts[POS] = [ok([position(quantity=2)]), ok([position(quantity=2)])]
    result, _ = run(rts)
    assert result["data"]["holdings"]


def test_positions_reread_rate_limited_leaves_holdings_out():
    rts = routes()
    rts[POS] = [ok([position()]), (429, {"x-ratelimit-reset": FAR}, {})]
    result, _ = run(rts)
    assert "holdings" not in result["data"]
    assert result["data"]["accounts"]


def test_position_without_instrument_is_skipped():
    rts = routes()
    rts[POS] = [ok([position(), {"quantity": 1}])]
    result, _ = run(rts)
    assert len(result["data"]["holdings"]) == 1


@pytest.mark.parametrize("secrets", [{}, None, {"api_key": None, "api_secret": "x"}])
def test_missing_credentials_need_auth(secrets):
    p = Trading212(http=FakeHttp(routes()), clock=lambda: 0.0, wall=lambda: WALL0)
    with pytest.raises(NeedsAuth):
        p.sync({"state": None}, SimpleNamespace(secrets=secrets, config=None))


def test_metadata_server_error_does_not_fail_sync():
    result, _ = run(routes(**{META: [(500, {}, b"")]}))
    assert result["data"]["holdings"]
    assert "type" not in result["state"]["instruments"]["AAPL_US_EQ"]
    assert "instruments_at" not in result["state"]


def test_history_walked_orders_first():
    _, http = run(routes())
    walked = [url.split("/history/")[1].split("?")[0] for url, _ in http.calls if "/history/" in url]
    assert walked == ["orders", "transactions", "dividends"]


def test_types_fetched_for_closed_and_ledger_tickers():
    state = {"account_id": "10000001", "orders_complete": True,
             "history": {e: {"phase": "incremental", "newest": "x"} for e in ("orders", "transactions", "dividends")},
             "ledger": {"MSFT_US_EQ": {"net": "0"}}, "closed": {"NVDA_US_EQ": True},
             "instruments": {"AAPL_US_EQ": {"name": "Apple", "type": "stock"},
                             "MSFT_US_EQ": {"name": "Microsoft"}, "NVDA_US_EQ": {"name": "Nvidia"}}}
    rts = routes(orders=[], **{META: [ok([instrument_meta("MSFT_US_EQ", "STOCK", "MSFT"),
                                          instrument_meta("NVDA_US_EQ", "ETF", "NVDA")])]})
    result, _ = run(rts, state=state)
    instruments = result["state"]["instruments"]
    assert instruments["MSFT_US_EQ"]["type"] == "stock"
    assert instruments["NVDA_US_EQ"]["type"] == "etf"
