from datetime import date
from decimal import Decimal

import pytest

from securo_trading212 import log
from securo_trading212.mapping import Fill, asset_type, fill_from_order, instrument_info, short_symbol
from tests.factories import order


@pytest.fixture(autouse=True)
def _reset_log():
    log.reset()


def test_buy_same_currency_net_includes_fee():
    item = order(1, quantity=3, price=10.0, net=-30.15, fx=1.0, currency="EUR",
                 taxes=[("CURRENCY_CONVERSION_FEE", 0.15, "EUR")])
    fill = fill_from_order(item, "EUR")
    assert fill == Fill("1", "AAPL_US_EQ", date(2024, 1, 2), "buy", Decimal("3"), Decimal("10"), Decimal("0.15"))


def test_sell_same_currency_net_after_fee():
    item = order(2, side="SELL", quantity=2, price=50.0, net=99.90, currency="EUR",
                 taxes=[("FEE", 0.10, "EUR")])
    fill = fill_from_order(item, "EUR")
    assert fill.kind == "sell"
    assert fill.price == Decimal("50")
    assert fill.fee == Decimal("0.10")


def test_fx_rate_multiplies():
    fill = fill_from_order(order(3, price=100.0, net=-90.0, fx=0.9, currency="USD"), "EUR")
    assert fill.price == Decimal("90")
    assert fill.fee == 0


def test_fx_rate_divides():
    fill = fill_from_order(order(4, price=100.0, net=-90.0, fx=1.1111111, currency="USD"), "EUR")
    assert abs(fill.price - 90) < Decimal("0.001")


def test_foreign_currency_tax_converted():
    item = order(5, side="SELL", price=100.0, net=89.55, fx=0.9, currency="USD",
                 taxes=[("FINRA_FEE", 0.5, "USD")])
    fill = fill_from_order(item, "EUR")
    assert fill.fee == Decimal("0.45")
    assert fill.price == Decimal("90")


def test_mismatch_falls_back_and_warns(capsys):
    fill = fill_from_order(order(6, price=100.0, net=-50.0, currency="EUR"), "EUR")
    assert fill.price == Decimal("50")
    assert fill.fee == 0
    err = capsys.readouterr().err
    assert "didn't match" in err
    assert "50" not in err


def test_non_trade_fill_skipped(capsys):
    assert fill_from_order(order(7, fill_type="STOCK_SPLIT"), "EUR") is None
    assert capsys.readouterr().err == ""


def test_unknown_fill_type_logged(capsys):
    assert fill_from_order(order(8, fill_type="MERGER_X"), "EUR") is None
    assert "unknown fill type: MERGER_X" in capsys.readouterr().err


def test_no_fill_skipped():
    item = order(9)
    item["fill"] = None
    assert fill_from_order(item, "EUR") is None


def test_zero_quantity_and_bad_side_skipped():
    assert fill_from_order(order(10, quantity=0), "EUR") is None
    assert fill_from_order(order(11, side="HOLD"), "EUR") is None


def test_fill_state_roundtrip():
    fill = fill_from_order(order(12, quantity=3, price=10.0, net=-30.15, currency="EUR",
                                 taxes=[("F", 0.15, "EUR")]), "EUR")
    assert Fill.from_state(fill.to_state()) == fill
    assert fill.to_state() == ["12", "AAPL_US_EQ", "2024-01-02", "buy", "3", "10", "0.15"]


def test_asset_type():
    assert asset_type("STOCK") == "stock"
    assert asset_type("ETF") == "etf"
    assert asset_type("CRYPTOCURRENCY") == "crypto"
    assert asset_type("CRYPTO") == "crypto"
    assert asset_type("WARRANT") == "investment"
    assert asset_type(None) is None


def test_short_symbol():
    assert short_symbol("VUSAl_EQ", None) == "VUSAl"
    assert short_symbol("AAPL_US_EQ", "AAPL") == "AAPL"
    assert len(short_symbol("X" * 50, None)) == 32


def test_instrument_info_drops_bad_isin():
    assert instrument_info({"name": "Apple", "isin": "bad"}) == {"name": "Apple", "isin": None}
    assert instrument_info({"name": "Apple", "isin": "US0378331005"})["isin"] == "US0378331005"


def test_no_net_value_foreign_currency_skipped(capsys):
    item = order(13, price=100.0, net=None, currency="USD")
    assert fill_from_order(item, "EUR") is None
    err = capsys.readouterr().err
    assert "no net value and a foreign price" in err
    assert "100" not in err and "13" not in err


def test_no_net_value_unknown_currency_skipped():
    item = order(14, price=100.0, net=None)
    item["order"]["instrument"]["currency"] = None
    assert fill_from_order(item, "EUR") is None


def test_no_net_value_same_currency_uses_price(capsys):
    item = order(15, quantity=2, price=100.0, net=None, currency="EUR", taxes=[("F", 0.5, "EUR")])
    fill = fill_from_order(item, "EUR")
    assert (fill.price, fill.fee) == (Decimal("100"), Decimal("0.5"))
    assert "used its instrument price" in capsys.readouterr().err
