from decimal import Decimal
import pytest
from securo_trading212.numbers import number, parse_decimal
from securo_trading212 import log

@pytest.mark.parametrize("raw,expected", [
    (Decimal("1.50"), "1.5"), (Decimal("10"), "10"), (Decimal("1E+2"), "100"),
    (Decimal("0.123456789"), "0.12345679"), (Decimal("-0.000000001"), "0"),
    (Decimal("-2.5"), "-2.5"),
])
def test_number(raw, expected):
    assert number(raw) == expected

@pytest.mark.parametrize("raw,expected", [
    ("12.30", Decimal("12.30")), (7, Decimal(7)), (Decimal("1.1"), Decimal("1.1")),
    (None, None), ("", None), (True, None), ("abc", None), ("NaN", None), ("Infinity", None),
])
def test_parse_decimal(raw, expected):
    assert parse_decimal(raw) == expected

def test_unknown_logs_once_and_sanitises(capsys):
    log.reset()
    log.unknown("transaction type", "new_type<script>")
    log.unknown("transaction type", "new_type<script>")
    err = capsys.readouterr().err
    assert err.count("trading212: unknown transaction type: NEW_TYPESCRIPT") == 1
