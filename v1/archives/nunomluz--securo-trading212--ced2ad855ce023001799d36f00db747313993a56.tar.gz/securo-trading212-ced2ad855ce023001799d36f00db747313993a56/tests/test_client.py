import base64
from decimal import Decimal

import pytest

from securo_trading212 import client as client_mod
from securo_trading212.client import Client
from securo_trading212.errors import NeedsAuth, OutOfTime, RateLimited, Transient
from tests.factories import FakeHttp, ok

KEY, SECRET = "key-abc", "secret-xyz"
P = "/api/v0/equity/account/summary"
WALL0 = 1_700_000_000.0


def make(routes=None, environment=None, key=KEY, secret=SECRET, budget=40.0, http=None):
    now = [0.0]
    wall = [WALL0]
    sleeps = []

    def sleep(seconds):
        sleeps.append(seconds)
        now[0] += seconds
        wall[0] += seconds

    fake = http or FakeHttp(routes or {})
    c = Client(
        api_key=key,
        api_secret=secret,
        environment=environment,
        http=fake,
        clock=lambda: now[0],
        wall=lambda: wall[0],
        sleep=sleep,
        budget=budget,
    )
    return c, fake, now, wall, sleeps


def test_basic_auth_and_prefix():
    c, http, *_ = make({P: [ok({"a": 1})]})
    assert c.get("/equity/account/summary") == {"a": 1}
    url, headers = http.calls[0]
    assert url == "https://live.trading212.com/api/v0/equity/account/summary"
    assert headers["Authorization"] == "Basic " + base64.b64encode(b"key-abc:secret-xyz").decode()


def test_demo_environment_host():
    c, http, *_ = make({P: [ok({})]}, environment="DEMO")
    c.get(P)
    assert http.calls[0][0] == "https://demo.trading212.com" + P


def test_bad_environment_needs_auth():
    with pytest.raises(NeedsAuth) as ei:
        make(environment="paper")
    assert ei.value.code == "environment_invalid"


def test_missing_secret_needs_auth():
    with pytest.raises(NeedsAuth):
        make(secret="  ")


@pytest.mark.parametrize("path", ["https://evil.example/x", "//evil.example/x", "/a\\b", "equity/x"])
def test_foreign_page_link_refused(path):
    c, http, *_ = make({})
    with pytest.raises(Transient):
        c.get(path)
    assert http.calls == []


def test_401_needs_auth():
    c, *_ = make({P: [(401, {}, b"")]})
    with pytest.raises(NeedsAuth, match="rejected"):
        c.get(P)


def test_403_names_scope():
    body = b'{"message":"Scope( history:orders ) missing for API key"}'
    c, *_ = make({P: [(403, {}, body)]})
    with pytest.raises(NeedsAuth) as ei:
        c.get(P)
    assert "history:orders" in str(ei.value)
    assert ei.value.code == "permission_missing"


def test_403_without_scope():
    c, *_ = make({P: [(403, {}, b"nope")]})
    with pytest.raises(NeedsAuth) as ei:
        c.get(P)
    assert "isn't allowed to read this" in str(ei.value)
    assert ei.value.code == "permission_missing"


def test_500_transient_without_body():
    c, *_ = make({P: [(500, {}, b"SECRET-ish text")]})
    with pytest.raises(Transient) as ei:
        c.get(P)
    assert "SECRET" not in str(ei.value)
    assert "500" in str(ei.value)


def test_oserror_transient():
    def boom(url, headers, timeout):
        raise ConnectionResetError("secret url detail")

    c, *_ = make(http=boom)
    with pytest.raises(Transient) as ei:
        c.get(P)
    assert str(ei.value) == "Couldn't reach Trading 212 (ConnectionResetError)."


def test_unreadable_response():
    c, *_ = make({P: [(200, {}, b"<html>")]})
    with pytest.raises(Transient, match="unreadable"):
        c.get(P)


def test_decimal_parsing():
    c, *_ = make({P: [ok({"cash": 0.1})]})
    result = c.get(P)
    assert result["cash"] == Decimal("0.1")
    assert isinstance(result["cash"], Decimal)


def test_waits_for_short_rate_limit():
    c, http, _now, wall, sleeps = make({P: [ok({}, remaining="0", reset=str(int(WALL0) + 5)), ok({})]})
    c.get(P)
    c.get(P)
    assert sleeps == [5.5]
    assert len(http.calls) == 2


def test_rate_limit_tracked_per_path_without_query():
    c, http, _n, _w, sleeps = make({P: [ok({}, remaining="0", reset=str(int(WALL0) + 5)), ok({})]})
    c.get(P)
    c.get(P + "?limit=1")
    assert sleeps == [5.5]


def test_rate_limited_when_reset_beyond_budget():
    c, http, *_ = make({P: [ok({}, remaining="0", reset=str(int(WALL0) + 120))]})
    c.get(P)
    with pytest.raises(RateLimited):
        c.get(P)
    assert len(http.calls) == 1


def test_429_retries_once_then_rate_limited():
    c, http, _n, _w, sleeps = make({P: [(429, {"x-ratelimit-reset": str(int(WALL0) + 3)}, b""), ok({"a": 1})]})
    assert c.get(P) == {"a": 1}
    assert len(sleeps) == 1
    assert len(http.calls) == 2

    c, http, *_ = make({P: [(429, {"x-ratelimit-reset": str(int(WALL0) + 600)}, b"")]})
    with pytest.raises(RateLimited):
        c.get(P)
    assert len(http.calls) == 1


def test_429_twice_is_rate_limited():
    c, http, *_ = make({P: [(429, {"x-ratelimit-reset": str(int(WALL0) + 3)}, b"")]})
    with pytest.raises(RateLimited):
        c.get(P)
    assert len(http.calls) == 2


def test_out_of_time():
    c, http, now, *_ = make({P: [ok({})]}, budget=10)
    now[0] = 11
    with pytest.raises(OutOfTime):
        c.get(P)
    assert http.calls == []
    assert c.remaining() <= 0


@pytest.mark.parametrize(
    "reply",
    [(401, {}, b""), (403, {}, b"Scope( x ) missing"), (500, {}, b"body"), (404, {}, b"")],
)
def test_secret_never_in_messages(reply):
    c, *_ = make({P: [reply]})
    with pytest.raises(Exception) as ei:
        c.get(P)
    text = str(ei.value)
    assert KEY not in text and SECRET not in text and "trading212.com/api" not in text


def test_secret_never_in_oserror_message():
    def boom(url, headers, timeout):
        raise OSError(f"{KEY} {SECRET} {url}")

    c, *_ = make(http=boom)
    with pytest.raises(Transient) as ei:
        c.get(P)
    assert KEY not in str(ei.value) and SECRET not in str(ei.value)


def test_constants():
    assert client_mod.HOSTS == {"live": "live.trading212.com", "demo": "demo.trading212.com"}
    assert client_mod.API_PREFIX == "/api/v0"


# --- urllib_get and transport hardening ---------------------------------

import contextlib
import email.message
import http.client
import io
import urllib.error
import urllib.request


class _Resp:
    def __init__(self, status, headers, body):
        self.status = status
        self.headers = headers
        self._body = body
        self.read_sizes = []

    def read(self, n=-1):
        self.read_sizes.append(n)
        return self._body if n < 0 else self._body[:n]

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


def _msg(**h):
    m = email.message.Message()
    for k, v in h.items():
        m[k] = v
    return m


class _Opener:
    def __init__(self, result):
        self.result = result
        self.timeout = None

    def open(self, request, timeout=None):
        self.timeout = timeout
        if isinstance(self.result, BaseException):
            raise self.result
        return self.result


def test_urllib_get_lowercases_headers(monkeypatch):
    resp = _Resp(200, _msg(**{"X-RateLimit-Remaining": "3"}), b"{}")
    opener = _Opener(resp)
    monkeypatch.setattr(client_mod, "_opener", opener)
    status, headers, body = client_mod.urllib_get("https://x/y", {})
    assert (status, body) == (200, b"{}")
    assert headers == {"x-ratelimit-remaining": "3"}
    assert opener.timeout == client_mod.HTTP_TIMEOUT
    assert resp.read_sizes == [client_mod.MAX_RESPONSE_BYTES + 1]
    client_mod.urllib_get("https://x/y", {}, 7.5)
    assert opener.timeout == 7.5


def test_urllib_get_oversize_body_transient(monkeypatch):
    monkeypatch.setattr(client_mod, "MAX_RESPONSE_BYTES", 10)
    monkeypatch.setattr(client_mod, "_opener", _Opener(_Resp(200, _msg(), b"x" * 50)))
    with pytest.raises(Transient):
        client_mod.urllib_get("https://x/y", {})


def test_urllib_get_exact_limit_ok(monkeypatch):
    monkeypatch.setattr(client_mod, "MAX_RESPONSE_BYTES", 10)
    monkeypatch.setattr(client_mod, "_opener", _Opener(_Resp(200, _msg(), b"x" * 10)))
    assert client_mod.urllib_get("https://x/y", {})[2] == b"x" * 10


def test_urllib_get_http_error_caps_body(monkeypatch):
    err = urllib.error.HTTPError("https://x/y", 500, "m", _msg(**{"Retry-After": "1"}), io.BytesIO(b"e" * 10_000))
    monkeypatch.setattr(client_mod, "_opener", _Opener(err))
    status, headers, body = client_mod.urllib_get("https://x/y", {})
    assert status == 500
    assert len(body) == 4096
    assert headers == {"retry-after": "1"}


def test_redirects_not_followed():
    handler = client_mod._NoRedirect()
    req = urllib.request.Request("https://live.trading212.com/api/v0/x")
    assert handler.redirect_request(req, None, 302, "Found", _msg(Location="https://evil.example/"), "https://evil.example/") is None
    # The real opener's chain contains our handler, so a 3xx surfaces as an HTTPError status.
    assert any(isinstance(h, client_mod._NoRedirect) for h in client_mod._opener.handlers)


def test_http_exception_is_transient():
    def boom(url, headers, timeout):
        raise http.client.BadStatusLine(f"{KEY} {url}")

    c, *_ = make(http=boom)
    with pytest.raises(Transient) as ei:
        c.get(P)
    assert str(ei.value) == "Couldn't reach Trading 212 (BadStatusLine)."


@pytest.mark.parametrize("path", ["/a b", "/a\nb", "/a\x00b", "/a\tb", "/a\x7fb", "/a\rb"])
def test_control_chars_and_spaces_refused(path):
    c, http_, *_ = make({})
    with pytest.raises(Transient, match="unexpected page link"):
        c.get(path)
    assert http_.calls == []


def test_request_timeout_capped_by_remaining_budget():
    c, http, now, *_ = make({P: [ok({})]}, budget=40)
    c.get(P)
    now[0] = 35.0
    c.get(P)
    now[0] = 39.5
    c.get(P)
    assert http.timeouts == [client_mod.HTTP_TIMEOUT, 5.0, 1]
