from datetime import date, timedelta
from decimal import Decimal

from securo_trading212.ledger import FLOOR, Entry, apply, balance, balancing_trades
from securo_trading212.mapping import Fill

D = Decimal
TODAY = date(2026, 3, 1)


def fill(id_, day, kind, qty, price=10, fee=0):
    return Fill(id_, "AAPL_US_EQ", day, kind, D(qty), D(price), D(fee))


def entry(**kw):
    return Entry(**kw)


def test_apply_tracks_net_low_first():
    fills = [
        fill("c", date(2026, 1, 4), "buy", 1),
        fill("a", date(2026, 1, 2), "buy", 2),
        fill("b", date(2026, 1, 3), "sell", 3),
    ]
    e = apply(Entry(), fills)
    assert e.net == D(0)
    assert e.low == D(-1)
    assert e.first == date(2026, 1, 2)


def test_apply_same_day_buys_first():
    day = date(2026, 1, 2)
    e = apply(Entry(), [fill("a", day, "sell", 1), fill("b", day, "buy", 1)])
    assert e.low == D(0)
    assert e.net == D(0)


def test_apply_returns_new_entry_and_keeps_earlier_first():
    base = Entry(net=D(1), low=D(-2), first=date(2025, 1, 1),
                 days={"2025-01-01": D(-2), "2025-01-02": D(3)})
    e = apply(base, [fill("a", date(2026, 1, 2), "buy", 1)])
    assert base.net == D(1)
    assert e.net == D(2)
    assert e.low == D(-2)
    assert e.first == date(2025, 1, 1)


def test_apply_average_cost_of_held_lots():
    e = apply(Entry(), [
        fill("a", date(2026, 1, 2), "buy", 2, price=100, fee=1),
        fill("b", date(2026, 1, 3), "buy", 2, price=200, fee=1),
        fill("c", date(2026, 1, 4), "sell", 1, price=300),
    ])
    assert e.cost == D(602) * 3 / 4
    assert e.sold == D(1) and e.sold_value == D(300)


def test_apply_sell_beyond_held_lots_empties_cost_and_records_dip():
    e = apply(Entry(), [
        fill("a", date(2026, 1, 2), "buy", 1, price=100),
        fill("b", date(2026, 1, 3), "sell", 3, price=50),
        fill("c", date(2026, 1, 4), "sell", 1, price=80),
    ])
    assert e.cost == 0
    assert e.low == D(-3)
    # 2 units dipped at 50, then 1 more at 80
    assert e.dip_value == D(180)


def test_balanced_needs_nothing():
    e = balance(entry(net=D(2)), D(2), unit_price=D(5), today=TODAY)
    assert e.open == 0 and e.adjust == 0
    assert balancing_trades(e, "10000001", "AAPL_US_EQ") == []


def test_missing_units_opening_buy():
    first = date(2026, 1, 2)
    e = balance(entry(net=D(2), first=first), D(5), cost_price=D(100), unit_price=D(90), today=TODAY)
    assert e.open == D(3)
    assert e.open_price == D(100)
    assert e.open_sent is True
    (trade,) = balancing_trades(e, "10000001", "AAPL_US_EQ")
    assert trade["kind"] == "buy"
    assert trade["date"] == (first - timedelta(days=1)).isoformat()
    assert trade["quantity"] == "3"
    assert trade["price"] == "100"
    assert trade["fee"] == "0"


def test_dip_below_zero_opening_buy_priced_at_dipping_sells():
    e = balance(entry(net=D(0), low=D(-1), dip_value=D(7)), D(1), unit_price=D(9), today=TODAY)
    assert e.open == D(1)
    assert e.adjust == D(0)
    assert e.open_price == D(7)
    assert e.first == TODAY


def test_dip_opening_prefers_last_cost_price():
    e = balance(entry(net=D(-1), low=D(-1), dip_value=D(7)), D(0), cost_price=D(5), today=TODAY)
    assert (e.open, e.open_price) == (D(1), D(5))


def test_surplus_adjust_sell():
    e = balance(entry(net=D(5)), D(3), unit_price=D(20), today=TODAY)
    assert e.adjust == D(2)
    assert e.adjust_date == TODAY
    assert e.adjust_price == D(20)
    assert e.adjust_sent is True
    (trade,) = balancing_trades(e, "10000001", "AAPL_US_EQ")
    assert trade["kind"] == "sell"
    assert trade["date"] == TODAY.isoformat()
    assert trade["quantity"] == "2"


def test_adjust_without_unit_price_uses_average_sell_price():
    e = balance(entry(net=D(2), sold=D(4), sold_value=D(100)), D(0), today=TODAY)
    assert (e.adjust, e.adjust_price) == (D(2), D(25))
    e = balance(entry(net=D(2)), D(0), today=TODAY)
    assert e.adjust_price == D(0)


def test_negative_unit_price_clamped():
    e = balance(entry(net=D(5)), D(3), unit_price=D(-1), today=TODAY)
    assert e.adjust_price == D(0)
    (trade,) = balancing_trades(e, "10000001", "AAPL_US_EQ")
    assert trade["price"] == "0"


def test_unsent_opening_disappears_when_no_longer_needed():
    e = balance(entry(net=D(2), open=D(0)), D(2), unit_price=D(9), today=TODAY)
    assert e.open == 0 and e.open_sent is False


def test_sent_opening_shrinks_to_floor_without_adjust():
    e = balance(
        entry(net=D(2), open=D(3), open_price=D(4), open_sent=True, first=date(2026, 1, 2)),
        D(2), unit_price=D(9), today=TODAY,
    )
    assert e.open == FLOOR
    assert e.open_price == D(4)
    assert e.adjust == 0 and e.adjust_sent is False
    (trade,) = balancing_trades(e, "10000001", "AAPL_US_EQ")
    assert trade["quantity"] == "0.000001"


def test_sent_adjust_shrinks_to_floor_and_keeps_date():
    old = date(2026, 2, 1)
    e = balance(
        entry(net=D(1), adjust=D(1), adjust_date=old, adjust_price=D(3), adjust_sent=True),
        D(1), unit_price=D(9), today=TODAY,
    )
    assert e.adjust == FLOOR
    assert (e.adjust_date, e.adjust_price) == (old, D(3))
    assert e.open == 0


def test_unchanged_adjust_keeps_date_and_price():
    old = date(2026, 2, 1)
    e = balance(
        entry(net=D(5), adjust=D(2), adjust_date=old, adjust_price=D(3), adjust_sent=True),
        D(3), unit_price=D(9), today=TODAY,
    )
    assert (e.adjust, e.adjust_date, e.adjust_price) == (D(2), old, D(3))


def test_shrinking_adjust_moves_to_today():
    # Fills that arrived since may sit on or after the old date; only today is always safe.
    old = date(2026, 2, 1)
    e = balance(
        entry(net=D(5), adjust=D(3), adjust_date=old, adjust_price=D(3), adjust_sent=True),
        D(3), unit_price=D(9), today=TODAY,
    )
    assert (e.adjust, e.adjust_date, e.adjust_price) == (D(2), TODAY, D(9))


def test_growing_adjust_moves_to_today():
    old = date(2026, 2, 1)
    e = balance(
        entry(net=D(5), adjust=D(1), adjust_date=old, adjust_price=D(3), adjust_sent=True),
        D(1), unit_price=D(9), today=TODAY,
    )
    assert (e.adjust, e.adjust_date, e.adjust_price) == (D(4), TODAY, D(9))


def test_resized_opening_repriced_unchanged_opening_keeps_price():
    base = entry(net=D(2), open=D(3), open_price=D(4), open_sent=True, first=date(2026, 1, 2))
    assert balance(base, D(5), cost_price=D(50), today=TODAY).open_price == D(4)
    grown = balance(base, D(6), cost_price=D(50), today=TODAY)
    assert (grown.open, grown.open_price) == (D(4), D(50))


def test_residual_cost_prices_opening():
    # 2 held at 100 each, position 5 costing 560 -> 3 more at 120
    e = balance(entry(net=D(2), cost=D(200), first=date(2026, 1, 2)), D(5),
                total_cost=D(560), cost_price=D(112), unit_price=D(130), today=TODAY)
    assert (e.open, e.open_price) == (D(3), D(120))


def test_residual_cost_clamped_at_zero():
    e = balance(entry(net=D(2), cost=D(300), first=date(2026, 1, 2)), D(5),
                total_cost=D(200), cost_price=D(40), today=TODAY)
    assert e.open_price == D(0)


def test_dip_only_opening_ignores_residual():
    e = balance(entry(net=D(1), low=D(-1), dip_value=D(50), cost=D(60)), D(1),
                total_cost=D(60), cost_price=D(60), unit_price=D(70), today=TODAY)
    assert (e.open, e.open_price) == (D(1), D(60))
    assert e.adjust == D(1)


def test_opening_without_fills_dated_before_position_created():
    created = date(2025, 5, 10)
    e = balance(entry(), D(2), cost_price=D(1), since=created, today=TODAY)
    assert e.first == created
    (trade,) = balancing_trades(e, "10000001", "AAPL_US_EQ")
    assert trade["date"] == "2025-05-09"


def test_opening_created_today_or_later_uses_today():
    e = balance(entry(), D(2), cost_price=D(1), since=TODAY + timedelta(days=1), today=TODAY)
    assert e.first == TODAY


def test_within_tolerance_no_change():
    for target in (D(2) + D("0.000005"), D(2) - D("0.000005")):
        e = balance(entry(net=D(2)), target, unit_price=D(5), today=TODAY)
        assert e.open == 0 and e.adjust == 0


def test_entry_state_roundtrip():
    e = Entry(
        net=D("1.5"),
        low=D("-2"),
        first=date(2026, 1, 2),
        open=D("3"),
        open_price=D("100.25"),
        adjust=D("0.5"),
        adjust_date=TODAY,
        adjust_price=D("20"),
        open_sent=True,
        adjust_sent=True,
        cost=D("12.5"),
        sold=D("2"),
        sold_value=D("40"),
        dip_value=D("30"),
        days={"2026-01-02": D("-2"), "2026-01-05": D("3.5")},
    )
    state = e.to_state()
    assert state["first"] == "2026-01-02"
    assert state["net"] == "1.5"
    assert state["open_sent"] is True
    assert state["days"] == {"2026-01-02": "-2", "2026-01-05": "3.5"}
    assert Entry.from_state(state) == e
    assert Entry.from_state(None) == Entry()


def test_entry_from_older_state_marks_sent_trades():
    e = Entry.from_state({"net": "1", "open": "2", "adjust": "0"})
    assert e.open_sent is True and e.adjust_sent is False


def test_entry_from_state_without_days_keeps_its_net_and_low():
    # Written before days were kept: the net sits on the first date, the low stays a floor.
    e = Entry.from_state({"net": "3", "low": "-2", "first": "2026-01-02"})
    assert e.days == {"2026-01-02": D(3)} and e.bound == D(-2)
    later = apply(e, [fill("a", date(2026, 1, 9), "sell", 1)])
    assert (later.net, later.low) == (D(2), D(-2))
    assert Entry.from_state({"net": "0"}).days == {}


def test_balancing_trade_ids():
    e = Entry(
        first=date(2026, 1, 2),
        open=D(1),
        open_price=D(1),
        adjust=D(1),
        adjust_date=TODAY,
        adjust_price=D(1),
    )
    ids = [t["external_id"] for t in balancing_trades(e, "10000001", "AAPL_US_EQ")]
    assert ids == [
        "t212:10000001:opening:AAPL_US_EQ",
        "t212:10000001:adjust:AAPL_US_EQ",
    ]


def test_apply_removes_cost_by_held_lots_after_a_dip():
    e = apply(Entry(), [
        fill("a", date(2026, 1, 2), "sell", 10, price=120),
        fill("b", date(2026, 1, 3), "buy", 5, price=100),
        fill("c", date(2026, 1, 4), "sell", 2, price=130),
    ])
    # held lots are net - low = 5 before the last sell, though net is -5
    assert (e.net, e.low) == (D(-7), D(-10))
    assert e.cost == D(300)


def test_apply_records_net_change_per_day():
    e = apply(Entry(), [fill("a", date(2026, 1, 2), "buy", 3), fill("b", date(2026, 1, 2), "sell", 1),
                        fill("c", date(2026, 1, 5), "buy", 2)])
    assert e.days == {"2026-01-02": D(2), "2026-01-05": D(2)}
    assert e.net == D(4)


def test_late_sell_gives_exact_low():
    e = apply(Entry(), [fill("a", date(2026, 1, 1), "buy", 5), fill("c", date(2026, 1, 3), "buy", 5)])
    late = apply(e, [fill("b", date(2026, 1, 2), "sell", 7, price=110)])
    # replayed by date: 5, -2, 3
    assert (late.net, late.low) == (D(3), D(-2))
    assert late.dip_value == D(220)


def test_late_sell_with_enough_units_leaves_low_at_zero():
    e = apply(Entry(), [fill("a", date(2026, 1, 1), "buy", 100), fill("c", date(2026, 1, 3), "buy", 10)])
    late = apply(e, [fill("b", date(2026, 1, 2), "sell", 100, price=150)])
    assert (late.net, late.low) == (D(10), D(0))


def test_late_buy_before_a_dip_raises_low():
    e = apply(Entry(), [fill("a", date(2026, 1, 2), "sell", 2, price=50), fill("c", date(2026, 1, 5), "buy", 1)])
    assert e.low == D(-2) and e.dip_value == D(100)
    late = apply(e, [fill("b", date(2026, 1, 1), "buy", 4)])
    assert (late.net, late.low) == (D(3), D(0))
    assert late.dip_value == D(0)


def test_same_day_buy_arriving_after_the_sell_raises_low():
    e = apply(Entry(), [fill("a", date(2026, 1, 1), "buy", 5)])
    e = apply(e, [fill("c", date(2026, 1, 2), "sell", 10)])
    assert e.low == D(-5)
    e = apply(e, [fill("b", date(2026, 1, 2), "buy", 5)])
    assert (e.net, e.low) == (D(0), D(0))


def test_opening_and_adjust_together_when_dip_exceeds_shortfall():
    e = Entry(net=D(3), low=D(-7), first=date(2026, 1, 1), cost=D(800))
    b = balance(e, D(3), cost_price=D(100), unit_price=D(105), today=TODAY)
    assert (b.open, b.adjust, b.adjust_date) == (D(7), D(7), TODAY)


def test_opening_price_blends_shortfall_and_dip():
    # 2 units sold before the history (at 50), 3 held units no fill explains; 1 bought at 100 held.
    e = Entry(net=D(-1), low=D(-2), dip_value=D(100), cost=D(100), first=date(2026, 1, 2))
    b = balance(e, D(4), total_cost=D(460), cost_price=D(115), today=TODAY)
    # shortfall 3 at (460 - 100) = 360 in all; dip 2 at the last cost price 115
    assert b.open == D(5)
    assert b.open_price == (D(360) + 2 * D(115)) / 5


def held(quantity, day, **kw):
    return Entry(net=D(quantity), first=day, days={day.isoformat(): D(quantity)}, **kw)


def test_sell_on_or_before_adjust_date_moves_adjust_to_today():
    old = date(2026, 2, 1)
    base = held(1, date(2026, 1, 5), adjust=D(1), adjust_date=old, adjust_price=D(3), adjust_sent=True)
    # the sell the adjust stood in for arrives, with a buy whose own sell still lags
    e = apply(base, [fill("s", old, "sell", 1), fill("b", date(2026, 2, 3), "buy", 1)])
    e = balance(e, D(0), unit_price=D(9), today=TODAY)
    assert (e.adjust, e.adjust_date, e.adjust_price) == (D(1), TODAY, D(9))


def test_buy_before_adjust_date_keeps_it():
    old = date(2026, 2, 1)
    base = held(1, date(2026, 1, 5), adjust=D(1), adjust_date=old, adjust_price=D(3), adjust_sent=True)
    e = apply(base, [fill("b", date(2026, 1, 20), "buy", 1)])
    assert e.adjust_date == old


def test_floored_adjust_without_date_gets_today():
    e = Entry(net=D(1), adjust=FLOOR, adjust_sent=True)
    e = balance(e, D(1), today=TODAY)
    (trade,) = balancing_trades(e, "10000001", "AAPL_US_EQ")
    assert (trade["quantity"], trade["date"]) == ("0.000001", TODAY.isoformat())
