import json
import re
from pathlib import Path

from securo_trading212 import client, payload


def test_manifest_matches_code():
    m = json.loads(Path("securo-plugin.json").read_text("utf-8"))
    assert {n["host"] for n in m["network"]} == set(client.HOSTS.values())
    assert m["runtime"]["entrypoint"] == "securo_trading212.plugin:plugin"
    integ = m["contributes"]["integrations"][0]
    assert {f["key"] for f in integ["fields"]} == {"api_key", "api_secret", "environment"}
    assert all(f.get("secret") for f in integ["fields"] if f["key"] != "environment")
    assert payload.LOGO in m["logos"] and Path(m["logos"][payload.LOGO]).is_file()
    assert re.fullmatch(r"[a-z0-9-]+/securo-trading212", m["id"])
    assert "api_scopes" not in m


def test_icons_are_small_pngs():
    for p in ("icon.png", "logos/trading212.png"):
        data = Path(p).read_bytes()
        assert data[:8] == b"\x89PNG\r\n\x1a\n" and len(data) <= 64 * 1024
