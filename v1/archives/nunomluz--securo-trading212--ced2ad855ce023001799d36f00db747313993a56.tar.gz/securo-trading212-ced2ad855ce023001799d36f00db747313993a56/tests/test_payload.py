from datetime import date
from decimal import Decimal

import pytest

from securo_trading212 import errors, payload
from securo_trading212.mapping import CashTxn, Fill
from tests.factories import position, summary

D = Decimal
TODAY = date(2026, 3, 1)
AAPL = "AAPL_US_EQ"


def fill(id_, ticker=AAPL, kind="buy", qty=1, price=100, day=date(2024, 1, 2)):
    return Fill(id_, ticker, day, kind, D(qty), D(price), D(0))


def build(positions, state, account_id="10000001", today=TODAY):
    return payload.build_holdings(account_id=account_id, currency="EUR", positions=positions,
                                  state=state, today=today)


def replay(trades, target):
    """Securo's reconciliation: (ordered trades, lowest running quantity) or None."""
    trades = list(trades)
    if not trades:
        return None
    ordered = sorted(trades, key=lambda t: (t["date"], t["kind"] != "buy", t["external_id"]))
    largest = max([abs(target), *(D(t["quantity"]) for t in trades)])
    tolerance = max(D("0.0001"), largest * D("0.000001"))
    position = lowest = D(0)
    for t in ordered:
        position += D(t["quantity"]) if t["kind"] == "buy" else -D(t["quantity"])
        lowest = min(lowest, position)
        if position < -tolerance:
            return None
    return (ordered, lowest) if abs(position - target) <= tolerance else None


class Securo:
    """Stores reported trades by id the way Securo does: the reported trade wins."""

    def __init__(self):
        self.stored: dict[str, dict] = {}

    def write(self, holdings):
        for h in holdings:
            if h["trades"] is None:
                continue
            merged = dict(self.stored.get(h["external_id"], {}))
            merged.update({t["external_id"]: t for t in h["trades"]})
            result = replay(merged.values(), D(h["quantity"]))
            assert result is not None, "trades don't add up to the position"
            ordered, lowest = result
            assert lowest >= 0, "replay went below zero"
            self.stored[h["external_id"]] = {t["external_id"]: t for t in ordered}

    def trades(self, ticker):
        return self.stored[f"t212:10000001:{ticker}"]

    def realized_gain(self, ticker):
        """Average-cost realized gain over the stored trades, replayed in Securo's order."""
        units = cost = gain = D(0)
        stored = self.trades(ticker).values()
        for t in sorted(stored, key=lambda t: (t["date"], t["kind"] != "buy", t["external_id"])):
            quantity, price = D(t["quantity"]), D(t["price"])
            if t["kind"] == "buy":
                units += quantity
                cost += quantity * price
            else:
                average = cost / units if units > 0 else D(0)
                gain += quantity * (price - average)
                cost -= average * min(quantity, units)
                units -= quantity
        return gain


def by_id(holdings, ticker):
    return next(h for h in holdings if h["external_id"].endswith(f":{ticker}"))


def test_account_record():
    rec = payload.account_record(summary(available=100.5, in_pies=20, reserved=4.5), [])
    assert rec["balance"] == "125"
    assert rec["masked_number"] == "0001"
    assert rec["name"] == "Trading 212 (EUR)"
    assert rec["external_id"] == "t212:10000001"
    assert rec["type"] == "investment"
    assert rec["institution_logo"] == "trading212"


def test_account_keeps_foreign_currency_txn_and_dedupes():
    txn = CashTxn("t212:1:txn:a", "Deposit", D(5), date(2024, 1, 1), "credit", "USD", "Trading 212")
    rec = payload.account_record(summary(), [txn, txn])
    assert len(rec["transactions"]) == 1
    assert rec["transactions"][0]["currency"] == "USD"
    assert rec["transactions"][0]["amount"] == "5"


def test_account_too_many_transactions(monkeypatch):
    monkeypatch.setattr(payload, "MAX_TRANSACTIONS", 1)
    txns = [CashTxn(f"t212:1:txn:{i}", "D", D(1), date(2024, 1, 1), "credit", "EUR", "T") for i in "ab"]
    with pytest.raises(errors.Transient):
        payload.account_record(summary(), txns)


def test_open_position_with_matching_trades():
    state = {"pending": {AAPL: [fill("f1", qty=2).to_state()]}}
    h = by_id(build([position()], state), AAPL)
    assert h["quantity"] == "2"
    assert h["current_value"] == "300"
    assert h["unit_price"] == "150"
    assert h["purchase_price"] == "250"
    assert h["purchase_date"] == "2024-01-02"
    assert h["isin"] == "US0378331005"
    assert h["ticker"] == "AAPL"
    assert h["metadata"]["average_price_paid"] == "140"
    assert [t["external_id"] for t in h["trades"]] == ["t212:10000001:fill:f1"]
    assert state["ledger"][AAPL]["net"] == "2"
    assert AAPL not in state["pending"]


def test_position_without_history_gets_opening():
    h = by_id(build([position()], {}), AAPL)
    assert len(h["trades"]) == 1
    t = h["trades"][0]
    assert (t["kind"], t["quantity"], t["price"]) == ("buy", "2", "125")


def test_sold_out_listed_with_zero():
    state = {"ledger": {AAPL: {"net": "0", "low": "0", "first": "2024-01-02"}},
             "instruments": {AAPL: {"name": "Apple", "isin": "US0378331005", "type": "stock", "short": None}}}
    h = by_id(build([], state), AAPL)
    assert h["quantity"] == "0" and h["current_value"] == "0"
    assert h["name"] == "Apple" and h["type"] == "stock"
    assert h["trades"] is None
    assert state["closed"][AAPL] is True


def test_sold_out_with_fills_sends_them():
    state = {"pending": {AAPL: [fill("b", qty=2).to_state(), fill("s", kind="sell", qty=2).to_state()]}}
    h = by_id(build([], state), AAPL)
    assert [t["kind"] for t in h["trades"]] == ["buy", "sell"]


def test_closed_listed_again_next_call():
    state = {"ledger": {AAPL: {"net": "0"}}}
    build([], state)
    assert by_id(build([], state), AAPL)["quantity"] == "0"


def test_reopened_position_leaves_closed():
    state = {"closed": {AAPL: True}}
    build([position()], state)
    assert AAPL not in state["closed"]


def test_trade_budget_defers_ticker(monkeypatch):
    monkeypatch.setattr(payload, "MAX_TRADES", 5 + 2 * 2)
    a, b = "A_US_EQ", "B_US_EQ"
    state = {"pending": {a: [fill("a1", a).to_state(), fill("a2", a).to_state()],
                         b: [fill(f"b{i}", b).to_state() for i in range(4)]}}
    out = build([position(a, quantity=2), position(b, quantity=4)], state)
    assert len(by_id(out, a)["trades"]) == 2
    assert by_id(out, b)["trades"] is None
    assert len(state["pending"][b]) == 4
    assert a not in state["pending"]


def test_ticker_larger_than_whole_budget_never_sent(monkeypatch):
    monkeypatch.setattr(payload, "MAX_TRADES", 4)
    state = {"pending": {AAPL: [fill(f"x{i}").to_state() for i in range(3)]}}
    out = build([position()], state)
    assert by_id(out, AAPL)["trades"] is None
    assert len(state["pending"][AAPL]) == 3


def test_balancing_trades_resent():
    state = {}
    first = by_id(build([position()], state), AAPL)["trades"]
    second = by_id(build([position()], state), AAPL)["trades"]
    assert first and first == second
    assert first[0]["external_id"] == "t212:10000001:opening:AAPL_US_EQ"


def test_negative_price_and_fee_clamped():
    bad = Fill("n", AAPL, date(2024, 1, 2), "buy", D(2), D(-1), D(-3))
    h = by_id(build([position()], {"pending": {AAPL: [bad.to_state()]}}), AAPL)
    assert h["trades"][0]["price"] == "0" and h["trades"][0]["fee"] == "0"


def test_no_trade_amount_is_float():
    state = {"pending": {AAPL: [fill("f1", qty=1).to_state()]}}
    for h in build([position(), position("MSFT_US_EQ", name="Microsoft", isin=None)], state):
        for key in ("current_value", "quantity", "unit_price", "purchase_price"):
            assert isinstance(h[key], str)
        for t in h["trades"] or []:
            for key in ("quantity", "price", "fee"):
                assert isinstance(t[key], str)
        assert all(isinstance(v, str) for v in h["metadata"].values())


def kinds(trades):
    return {t["external_id"].split(":")[2]: t for t in trades or []}


def test_history_lag_opening_shrinks_to_floor():
    securo, state = Securo(), {}
    pos = position(quantity=1, value=150, cost=100)
    first = by_id(build([pos], state, today=date(2024, 6, 1)), AAPL)
    securo.write([first])
    assert [(t["quantity"], t["price"]) for t in first["trades"]] == [("1", "100")]

    state["pending"] = {AAPL: [fill("f1", qty=1, price=100, day=date(2024, 5, 30)).to_state()]}
    second = by_id(build([pos], state, today=date(2024, 6, 2)), AAPL)
    securo.write([second])
    got = kinds(second["trades"])
    assert set(got) == {"fill", "opening"}
    assert got["opening"]["quantity"] == "0.000001"
    assert "adjust" not in kinds(securo.trades(AAPL).values())


def test_positions_glitch_adjust_appears_then_shrinks_to_floor():
    securo, state = Securo(), {"pending": {AAPL: [fill("f1", qty=1, price=100).to_state()]}}
    pos = position(quantity=1, value=150, cost=100)
    securo.write(build([pos], state, today=date(2024, 6, 1)))

    glitch = by_id(build([], state, today=date(2024, 6, 2)), AAPL)
    securo.write([glitch])
    (adjust,) = glitch["trades"]
    assert (adjust["kind"], adjust["quantity"], adjust["price"], adjust["date"]) == (
        "sell", "1", "150", "2024-06-02")

    back = by_id(build([pos], state, today=date(2024, 6, 3)), AAPL)
    securo.write([back])
    (adjust,) = back["trades"]
    assert (adjust["quantity"], adjust["date"]) == ("0.000001", "2024-06-02")
    assert "opening" not in kinds(securo.trades(AAPL).values())


def test_closed_ticker_with_only_a_sell_opens_at_the_sell_price():
    state = {"pending": {AAPL: [fill("s1", kind="sell", qty=2, price=160).to_state()]}}
    h = by_id(build([], state), AAPL)
    Securo().write([h])
    opening = kinds(h["trades"])["opening"]
    assert (opening["quantity"], opening["price"]) == ("2", "160")


def test_closed_ticker_adjust_uses_last_seen_unit_price():
    state = {"pending": {AAPL: [fill("b1", qty=2, price=100).to_state()]}}
    build([position(quantity=2, value=300, cost=200)], state, today=date(2024, 6, 1))
    assert state["instruments"][AAPL]["last_unit_price"] == "150"
    assert state["instruments"][AAPL]["last_cost_price"] == "100"
    h = by_id(build([], state, today=date(2024, 6, 2)), AAPL)
    adjust = kinds(h["trades"])["adjust"]
    assert (adjust["quantity"], adjust["price"]) == ("2", "150")


def test_closed_ticker_opening_uses_last_seen_cost_price():
    securo, state = Securo(), {}
    securo.write(build([position(quantity=2, value=300, cost=250)], state, today=date(2024, 6, 1)))
    state["pending"] = {AAPL: [fill("s1", kind="sell", qty=3, price=160, day=date(2024, 6, 1)).to_state()]}
    h = by_id(build([], state, today=date(2024, 6, 2)), AAPL)
    securo.write([h])
    opening = kinds(h["trades"])["opening"]
    assert (opening["quantity"], opening["price"]) == ("3", "125")


def test_split_shares_open_at_zero_cost():
    state = {"pending": {AAPL: [fill("b1", qty=10, price=100).to_state()]}}
    h = by_id(build([position(quantity=20, value=2400, cost=1000)], state), AAPL)
    Securo().write([h])
    opening = kinds(h["trades"])["opening"]
    assert (opening["quantity"], opening["price"]) == ("10", "0")


def test_transferred_in_shares_open_at_their_cost_before_position_created():
    h = by_id(build([position(quantity=5, value=600, cost=500, created="2023-04-05T10:00:00Z")], {}),
              AAPL)
    (opening,) = h["trades"]
    assert (opening["quantity"], opening["price"], opening["date"]) == ("5", "100", "2023-04-04")


def test_partial_history_opens_at_residual_cost():
    state = {"pending": {AAPL: [fill("b1", qty=2, price=100).to_state()]}}
    h = by_id(build([position(quantity=5, value=600, cost=560)], state), AAPL)
    opening = kinds(h["trades"])["opening"]
    assert (opening["quantity"], opening["price"]) == ("3", "120")


def test_negative_cost_and_value_clamped_where_securo_requires():
    h = by_id(build([position(quantity=2, value=-10, cost=-5)], {}), AAPL)
    assert h["purchase_price"] == "0"
    assert h["unit_price"] == "0"
    assert h["current_value"] == "-10"


def test_units_sold_before_history_then_rebought_keep_their_gain():
    # 10 held from before the history, sold at 120; 5 bought back at 100.
    securo = Securo()
    state = {"pending": {AAPL: [fill("s1", kind="sell", qty=10, price=120, day=date(2024, 1, 5)).to_state(),
                                fill("b1", qty=5, price=100, day=date(2024, 1, 8)).to_state()]}}
    h = by_id(build([position(quantity=5, value=500, cost=500)], state), AAPL)
    securo.write([h])
    opening = kinds(h["trades"])["opening"]
    assert (opening["quantity"], opening["price"]) == ("10", "100")
    assert securo.realized_gain(AAPL) == D(200)


def test_transferred_in_units_partly_sold_keep_their_cost():
    # 10 transferred in at 100 each, 4 sold at 120; Trading 212 holds 6 costing 600.
    securo = Securo()
    state = {"pending": {AAPL: [fill("s1", kind="sell", qty=4, price=120, day=date(2024, 1, 5)).to_state()]}}
    h = by_id(build([position(quantity=6, value=720, cost=600)], state), AAPL)
    securo.write([h])
    opening = kinds(h["trades"])["opening"]
    assert (opening["quantity"], opening["price"]) == ("10", "100")
    assert "adjust" not in kinds(h["trades"])
    assert securo.realized_gain(AAPL) == D(80)


def test_late_fill_dated_before_earlier_ones_still_reconciles():
    securo, state = Securo(), {}
    state["pending"] = {AAPL: [fill("b1", qty=5, price=100, day=date(2024, 1, 1)).to_state(),
                               fill("b3", qty=5, price=100, day=date(2024, 1, 3)).to_state()]}
    securo.write(build([position(quantity=10, value=1000, cost=1000)], state, today=date(2024, 1, 4)))
    # The sell from 2 January only shows up a sync later: 2 of its units predate the history.
    state["pending"] = {AAPL: [fill("s2", kind="sell", qty=7, price=110, day=date(2024, 1, 2)).to_state()]}
    h = by_id(build([position(quantity=5, value=500, cost=500)], state, today=date(2024, 1, 5)), AAPL)
    securo.write([h])  # asserts the merged replay never goes below zero and lands on 5
    got = kinds(h["trades"])
    assert got["opening"]["quantity"] == "2"
    assert "adjust" not in got


def test_late_sell_leaves_no_balancing_pair_behind():
    # Bought 100 on day 1 and 10 on day 3; the day-2 sale of 100 at 150 arrives a sync late.
    securo, state = Securo(), {}
    pos = position(quantity=10, value=1500, cost=1000)
    state["pending"] = {AAPL: [fill("001", qty=100, price=100, day=date(2024, 3, 1)).to_state(),
                               fill("003", qty=10, price=100, day=date(2024, 3, 3)).to_state()]}
    first = by_id(build([pos], state, today=date(2024, 3, 3)), AAPL)
    securo.write([first])
    assert kinds(first["trades"])["adjust"]["quantity"] == "100"
    state["pending"] = {AAPL: [fill("002", kind="sell", qty=100, price=150, day=date(2024, 3, 2)).to_state()]}
    second = by_id(build([pos], state, today=date(2024, 3, 4)), AAPL)
    securo.write([second])
    got = kinds(second["trades"])
    assert "opening" not in got
    assert got["adjust"]["quantity"] == "0.000001"
    assert abs(securo.realized_gain(AAPL) - D(5000)) < D("0.001")
    later = by_id(build([pos], state, today=date(2024, 3, 20)), AAPL)
    assert [t["quantity"] for t in later["trades"]] == ["0.000001"]


def test_sell_and_same_day_buy_arriving_apart_leave_no_pair():
    securo, state = Securo(), {}
    state["pending"] = {AAPL: [fill("001", qty=5, price=100, day=date(2024, 3, 1)).to_state()]}
    securo.write(build([position(quantity=5, value=500, cost=500)], state, today=date(2024, 3, 1)))
    # Day 2: bought 5 at 100 (lags), then sold 10 at 150.
    state["pending"] = {AAPL: [fill("003", kind="sell", qty=10, price=150, day=date(2024, 3, 2)).to_state()]}
    securo.write(build([], state, today=date(2024, 3, 2)))
    state["pending"] = {AAPL: [fill("002", qty=5, price=100, day=date(2024, 3, 2)).to_state()]}
    h = by_id(build([], state, today=date(2024, 3, 3)), AAPL)
    securo.write([h])
    got = kinds(h["trades"])
    assert got["opening"]["quantity"] == "0.000001"
    assert "adjust" not in got or got["adjust"]["quantity"] == "0.000001"
    assert abs(securo.realized_gain(AAPL) - D(500)) < D("0.001")


def test_lagging_same_day_sell_with_later_buy_reconciles():
    securo, state = Securo(), {}
    state["pending"] = {AAPL: [fill("b1", qty=9, price=100, day=date(2024, 2, 1)).to_state()]}
    securo.write(build([position(quantity=9, value=900, cost=900)], state, today=date(2024, 2, 1)))
    # One sell of 1 shows up, a same-day sell of 8 lags: the position is already 0.
    state["pending"] = {AAPL: [fill("s1", kind="sell", qty=1, price=100, day=date(2024, 2, 9)).to_state()]}
    securo.write(build([], state, today=date(2024, 2, 9)))
    # The lagging sell arrives with 5 bought on the 10th, whose same-day sell lags in turn.
    state["pending"] = {AAPL: [fill("s8", kind="sell", qty=8, price=100, day=date(2024, 2, 9)).to_state(),
                               fill("b2", qty=5, price=100, day=date(2024, 2, 10)).to_state()]}
    h = by_id(build([], state, today=date(2024, 2, 10)), AAPL)
    securo.write([h])
    assert kinds(h["trades"])["adjust"]["date"] == "2024-02-10"
