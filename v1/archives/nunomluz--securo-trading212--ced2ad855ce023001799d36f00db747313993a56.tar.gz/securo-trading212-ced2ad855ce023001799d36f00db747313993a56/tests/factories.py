"""Shared test builders and a fake HTTP transport. All values are made up."""

import json
from urllib.parse import urlsplit

Reply = tuple[int, dict, object]

ACCOUNT_ID = 10000001


class FakeHttp:
    """Routes by URL path+query (falling back to path); replies pop in order, last repeats."""

    def __init__(self, routes: dict[str, list[Reply]]) -> None:
        self.routes = {key: list(replies) for key, replies in routes.items()}
        self.calls: list[tuple[str, dict]] = []
        self.timeouts: list[float] = []

    def __call__(self, url: str, headers: dict[str, str], timeout: float):
        self.calls.append((url, dict(headers)))
        self.timeouts.append(timeout)
        parts = urlsplit(url)
        full = parts.path + (f"?{parts.query}" if parts.query else "")
        key = full if full in self.routes else parts.path
        if key not in self.routes:
            raise AssertionError(f"unrouted URL: {url}")
        replies = self.routes[key]
        status, resp_headers, body = replies.pop(0) if len(replies) > 1 else replies[0]
        if not isinstance(body, (bytes, bytearray)):
            body = json.dumps(body).encode()
        return status, {k.lower(): v for k, v in resp_headers.items()}, bytes(body)


def summary(id=ACCOUNT_ID, currency="EUR", available=100.5, in_pies=0, reserved=0):
    return {
        "id": id,
        "currency": currency,
        "totalValue": available + in_pies + reserved,
        "cash": {"availableToTrade": available, "inPies": in_pies, "reservedForOrders": reserved},
        "investments": {},
    }


def instrument(ticker="AAPL_US_EQ", name="Apple", isin="US0378331005", currency="USD"):
    return {"ticker": ticker, "name": name, "isin": isin, "currency": currency}


def position(
    ticker="AAPL_US_EQ",
    name="Apple",
    isin="US0378331005",
    currency="USD",
    quantity=2,
    value=300,
    cost=250,
    avg=140.0,
    price=170.0,
    created="2024-01-02T10:00:00Z",
    in_pies=0,
):
    return {
        "instrument": instrument(ticker, name, isin, currency),
        "quantity": quantity,
        "quantityInPies": in_pies,
        "averagePricePaid": avg,
        "currentPrice": price,
        "createdAt": created,
        "walletImpact": {
            "currency": "EUR",
            "totalCost": cost,
            "currentValue": value,
            "unrealizedProfitLoss": value - cost,
        },
    }


def order(
    fill_id,
    ticker="AAPL_US_EQ",
    side="BUY",
    quantity=1,
    price=100.0,
    net=-100.0,
    fx=1.0,
    taxes=(),
    filled="2024-01-02T10:00:00Z",
    fill_type="TRADE",
    currency="USD",
    name="Apple",
    isin="US0378331005",
):
    return {
        "order": {
            "id": fill_id,
            "side": side,
            "ticker": ticker,
            "currency": currency,
            "instrument": instrument(ticker, name, isin, currency),
        },
        "fill": {
            "id": fill_id,
            "quantity": quantity,
            "price": price,
            "type": fill_type,
            "filledAt": filled,
            "walletImpact": {
                "currency": "EUR",
                "netValue": net,
                "fxRate": fx,
                "taxes": [{"name": n, "quantity": q, "currency": c} for n, q, c in taxes],
            },
        },
    }


def dividend(
    reference,
    ticker="AAPL_US_EQ",
    amount=1.2,
    currency="EUR",
    paid="2024-03-01T00:00:00Z",
    name="Apple",
    type="ORDINARY",
):
    return {
        "reference": reference,
        "ticker": ticker,
        "amount": amount,
        "currency": currency,
        "paidOn": paid,
        "type": type,
        "instrument": instrument(ticker, name),
    }


def transaction(reference, type="DEPOSIT", amount=500, currency="EUR", when="2024-01-01T09:00:00Z"):
    return {"reference": reference, "type": type, "amount": amount, "currency": currency, "dateTime": when}


def page(items, next_path=None):
    return {"items": items, "nextPagePath": next_path}


def instrument_meta(ticker, type="STOCK", short="AAPL", name="Apple", currency="USD", isin="US0378331005"):
    return {
        "ticker": ticker,
        "type": type,
        "shortName": short,
        "name": name,
        "currencyCode": currency,
        "isin": isin,
    }


def ok(body, remaining="10", reset="0"):
    return 200, {"x-ratelimit-remaining": remaining, "x-ratelimit-reset": reset}, body
