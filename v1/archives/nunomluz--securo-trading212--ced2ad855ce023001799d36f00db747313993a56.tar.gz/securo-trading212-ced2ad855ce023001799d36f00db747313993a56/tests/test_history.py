from securo_trading212 import history
from tests.factories import FakeHttp, order, page, ok, transaction
from tests.test_client import WALL0, make

T = "/api/v0/equity/history/transactions"
O = "/api/v0/equity/history/orders"
P2 = f"{T}?cursor=2&limit=50"


def refs(items):
    return [i["reference"] for i in items]


def test_backfill_walks_all_pages():
    t3, t2, t1 = (transaction(r) for r in ("t3", "t2", "t1"))
    c, http, *_ = make({
        f"{T}?limit=50": [ok(page([t3, t2], P2))],
        P2: [ok(page([t1]))],
    })
    items, h, complete = history.advance(c, "transactions", {})
    assert refs(items) == ["t3", "t2", "t1"]
    assert complete is True
    assert h == {"phase": "incremental", "next": None, "newest": "t3"}


def test_backfill_resumes_after_rate_limit():
    t3, t2, t1 = (transaction(r) for r in ("t3", "t2", "t1"))
    routes = {
        f"{T}?limit=50": [ok(page([t3, t2], P2), remaining="0", reset=str(WALL0 + 1000))],
        P2: [ok(page([t1]))],
    }
    c, http, *_ = make(routes)
    items, h, complete = history.advance(c, "transactions", {})
    assert refs(items) == ["t3", "t2"]
    assert complete is False
    assert h["next"] == P2
    assert h["head"] == "t3"
    assert h.get("phase", "backfill") == "backfill"

    c2, *_ = make(http=http)
    items, h2, complete = history.advance(c2, "transactions", h)
    assert refs(items) == ["t1"]
    assert complete is True
    assert h2["newest"] == "t3"
    assert h2["phase"] == "incremental"
    assert h2["next"] is None


def test_incremental_stops_at_newest():
    items_ = [transaction(r) for r in ("t5", "t4", "t3", "t2")]
    c, http, *_ = make({f"{T}?limit=50": [ok(page(items_, P2))]})
    items, h, complete = history.advance(c, "transactions", {"phase": "incremental", "newest": "t3"})
    assert refs(items) == ["t5", "t4"]
    assert complete is True
    assert h["newest"] == "t5"
    assert len(http.calls) == 1


def test_incremental_nothing_new():
    items_ = [transaction(r) for r in ("t3", "t2")]
    c, *_ = make({f"{T}?limit=50": [ok(page(items_))]})
    items, h, complete = history.advance(c, "transactions", {"phase": "incremental", "newest": "t3"})
    assert items == []
    assert complete is True
    assert h["newest"] == "t3"


def test_orders_stop_on_older_numeric_id():
    c, *_ = make({f"{O}?limit=50": [ok(page([order(105), order(99)], f"{O}?cursor=2&limit=50"))]})
    items, h, complete = history.advance(c, "orders", {"phase": "incremental", "newest": "100"})
    assert [i["fill"]["id"] for i in items] == [105]
    assert h["newest"] == "105"
    assert complete is True


def test_empty_history():
    c, *_ = make({f"{T}?limit=50": [ok(page([]))]})
    items, h, complete = history.advance(c, "transactions", {})
    assert items == []
    assert complete is True
    assert h["newest"] is None


def test_item_key():
    assert history.item_key("orders", order(7)) == "7"
    assert history.item_key("orders", {"order": {"id": 9}}) == "o9"
    assert history.item_key("dividends", {"reference": "d1"}) == "d1"


def test_does_not_mutate_input():
    c, *_ = make({f"{T}?limit=50": [ok(page([transaction("t1")]))]})
    state = {"phase": "backfill", "next": None, "newest": None, "head": None}
    snapshot = dict(state)
    history.advance(c, "transactions", state)
    assert state == snapshot


def test_page_pointing_to_itself_ends_walk(capsys):
    from securo_trading212 import log
    log.reset()
    # The walk starts at the path without /api/v0; the page names itself with it.
    self_path = f"{T}?limit=50"
    c, http, *_ = make({self_path: [ok(page([transaction("t2")], self_path))]})
    items, h, complete = history.advance(c, "transactions", {})
    assert refs(items) == ["t2"]
    assert complete is True
    assert h["phase"] == "incremental" and h["next"] is None and h["newest"] == "t2"
    assert len(http.calls) == 1
    assert "a history page pointed to itself" in capsys.readouterr().err


def test_resumed_page_pointing_to_itself_ends_walk():
    c, http, *_ = make({P2: [ok(page([transaction("t1")], P2))]})
    items, h, complete = history.advance(c, "transactions", {"next": P2, "head": "t9"})
    assert complete is True and h["newest"] == "t9"
    assert len(http.calls) == 1
