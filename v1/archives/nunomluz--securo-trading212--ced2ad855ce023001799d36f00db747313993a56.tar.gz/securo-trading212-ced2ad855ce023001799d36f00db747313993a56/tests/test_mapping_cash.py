from datetime import date
from decimal import Decimal

from securo_trading212 import log
from securo_trading212.mapping import CashTxn, cash_from_dividend, cash_from_transaction, iso_date
from tests.factories import dividend, transaction

ACCOUNT = "10000001"


def setup_function(_):
    log.reset()


def test_deposit_is_credit():
    assert cash_from_transaction(transaction("r1", "DEPOSIT", 500), ACCOUNT) == CashTxn(
        "t212:10000001:txn:r1", "Deposit", Decimal("500"), date(2024, 1, 1), "credit", "EUR", "Trading 212"
    )


def test_withdraw_negative_amount_is_debit():
    txn = cash_from_transaction(transaction("r1", "WITHDRAW", -200), ACCOUNT)
    assert txn.amount == Decimal("200")
    assert txn.type == "debit"
    assert txn.description == "Withdrawal"


def test_fee_is_debit():
    txn = cash_from_transaction(transaction("r1", "FEE", 2), ACCOUNT)
    assert (txn.type, txn.amount, txn.description) == ("debit", Decimal("2"), "Fee")


def test_interest_is_credit():
    free = cash_from_transaction(transaction("r1", "INTEREST_ON_FREE_CASH", 1), ACCOUNT)
    lending = cash_from_transaction(transaction("r2", "LENDING_INTEREST", 1), ACCOUNT)
    assert (free.type, free.description) == ("credit", "Interest on cash")
    assert (lending.type, lending.description) == ("credit", "Share lending interest")


def test_transfer_follows_sign():
    assert cash_from_transaction(transaction("r1", "TRANSFER", -50), ACCOUNT).type == "debit"
    txn = cash_from_transaction(transaction("r2", "TRANSFER", 50), ACCOUNT)
    assert (txn.type, txn.description) == ("credit", "Transfer")


def test_unknown_type_follows_sign_and_logs(capsys):
    txn = cash_from_transaction(transaction("r1", "CASHBACK", 3), ACCOUNT)
    assert txn.type == "credit"
    assert txn.description == "Trading 212 cash movement"
    err = capsys.readouterr().err
    assert "unknown transaction type: CASHBACK" in err
    assert "3" not in err


def test_foreign_currency_kept():
    assert cash_from_transaction(transaction("r1", currency="usd"), ACCOUNT).currency == "USD"


def test_missing_reference_skipped(capsys):
    assert cash_from_transaction(transaction(None), ACCOUNT) is None
    assert "skipped a cash item" in capsys.readouterr().err


def test_zero_amount_skipped():
    assert cash_from_transaction(transaction("r1", amount=0), ACCOUNT) is None


def test_bad_currency_and_date_skipped():
    assert cash_from_transaction(transaction("r1", currency="EURO"), ACCOUNT) is None
    assert cash_from_transaction(transaction("r1", when="nonsense"), ACCOUNT) is None
    assert cash_from_transaction(transaction("r1", amount="x"), ACCOUNT) is None


def test_dividend():
    assert cash_from_dividend(dividend("d1", amount=1.2), ACCOUNT) == CashTxn(
        "t212:10000001:div:d1", "Dividend: Apple (ORDINARY)", Decimal("1.2"), date(2024, 3, 1), "credit", "EUR", "Apple"
    )


def test_negative_dividend_is_debit():
    txn = cash_from_dividend(dividend("d1", amount=-0.5), ACCOUNT)
    assert (txn.type, txn.amount) == ("debit", Decimal("0.5"))


def test_dividend_falls_back_to_ticker():
    item = dividend("d1")
    item["instrument"]["name"] = None
    txn = cash_from_dividend(item, ACCOUNT)
    assert txn.payee == "AAPL_US_EQ"


def test_iso_date_offset_to_utc():
    assert iso_date("2024-01-01T23:30:00-02:00") == date(2024, 1, 2)
    assert iso_date("2024-01-01T23:30:00Z") == date(2024, 1, 1)
    assert iso_date(None) is None


def test_numeric_reference_kept():
    txn = cash_from_transaction(transaction(123), ACCOUNT)
    assert txn.external_id == "t212:10000001:txn:123"
    assert cash_from_dividend(dividend(77), ACCOUNT).external_id == "t212:10000001:div:77"


def test_dividend_description_names_type_sanitised():
    assert cash_from_dividend(dividend("d1", type="return of-capital!"), ACCOUNT).description == (
        "Dividend: Apple (RETURNOFCAPITAL)")
    long = cash_from_dividend(dividend("d2", type="X" * 60), ACCOUNT).description
    assert long == f"Dividend: Apple ({'X' * 40})"


def test_dividend_description_without_type():
    for missing in (None, "", "!!"):
        assert cash_from_dividend(dividend("d1", type=missing), ACCOUNT).description == "Dividend: Apple"
