# Trading 212 plugin for Securo — design

Date: 2026-11-21
Status: approved

## Intent

A Securo code plugin that connects a Trading 212 account to Securo the way
Securo's own bank connections work: you add it from **+ Connect Bank**, enter
an API key, and Securo keeps it synced on a schedule. It is strictly
read-only: it never places orders, edits pies or moves money.

Each Trading 212 API key belongs to exactly one account (Invest or Stocks
ISA), so "adding accounts" means one Securo connection per key. Someone with
an Invest and an ISA account adds two connections.

What a synced account should show in Securo (same picture the IBKR plugin
gives):

- the account's cash balance
- every open position, with its current value
- the buys and sells behind each position, so gains are tracked
- closed positions with their trades and realized gain
- dividends, deposits, withdrawals, fees and interest as cash activity

## Goals

- Read-only sync of Invest and Stocks ISA accounts through the official
  Trading 212 Public API (v0).
- Full history on the first sync, then incremental.
- Re-running a sync never duplicates anything.
- Clear messages when the key is wrong or missing a permission.
- Pure standard-library Python, tested with pytest against fake HTTP.

## Non-goals

- Placing or cancelling orders, editing pies, any write endpoint.
- CFD accounts (the API doesn't support them).
- Pies as a concept in Securo. Pie holdings are just positions
  (`quantityInPies` is part of `quantity`); the deprecated pies endpoints are
  not used.
- Multi-currency wallets (the API reports everything in the account's
  primary currency).
- Sharing one connection across several keys/accounts.

## Anti-goals

- Requesting any API permission beyond read scopes. The README tells the
  person to create a key with read permissions only.
- Leaking the API key or secret into exception messages, logs, state, raw
  data or test fixtures.
- Real account numbers, tickers held or amounts committed to the repo. All
  fixtures are made up.
- Duplicated records after a format change: external-id formats are frozen
  once released.

## Constraints

From Securo (docs + the IBKR plugin, which is the reference implementation:
https://github.com/fredson-sumi/securo-ibkr/tree/346962d535609c663c561a95e467a71de0e6f328):

- Python, standard library only (no lockfile), runs on Python 3.14 in the
  plugin runner. Entry point `securo_trading212.plugin:plugin`.
- Each call is killed after 60 seconds.
- Network is limited to hosts declared in the manifest.
- `sync(params, context)` returns `{"state": ..., "data": ...}`. `data` is
  either `null` (nothing to write this time) or a provider-contract-1
  payload: `{"contract": 1, "accounts": [...], "holdings": [...]}`. Securo
  keeps the returned `state` only after it wrote `data`, so a failed sync
  repeats the same work.
- Securo matches every record by `external_id`.
- Amounts are plain decimal strings, at most 8 decimals, no exponent.
- A holding's trades are stored only if they add up to the reported
  quantity. A holding the plugin stops listing is archived, so closed
  holdings must be listed again on every sync (quantity 0, `trades: null`
  unless there are trades to send).
- `NeedsAuth` (exception named exactly that) means the person must fix the
  connection; any other exception is retried with backoff.
- Logo ships in the package (`logos/trading212.png`, manifest `logos`), not
  a URL.
- Requires `min_securo_version` 0.20.0 (first with provider plugins).

Confirmed in Securo's source (`backend/app/plugins/contract.py`,
`backend/app/services/connection_service.py`, `backend/plugin_runner/`,
commit c374ca5 on main, 2026-11-21):

- `null` vs `[]`: a list that is `null` (or left out) wasn't fetched, and
  Securo leaves what it has alone. `[]` means "fetched, empty" and archives
  every holding. A holding with `trades: null` leaves its stored ledger alone.
- Per reply: at most 20,000 transactions, 20,000 trades, 5,000 holdings,
  500 accounts; over a cap the whole reply is refused. The plugin's whole
  stdout (state + data) is capped at 16 MB. Memory 512 MB.
- Money columns keep 2 decimals, units/prices 6; trade quantity must be
  > 0, price ≥ 0, fee ≥ 0. Trade `price` is per unit in the holding's
  currency.
- Trades: Securo overlays the trades it stored for a holding with the ones
  reported, **by `external_id`, the reported one winning** (corrections
  allowed). It keeps the set only if replaying it (by date, buys first)
  never goes below zero and lands on the reported quantity (tolerance
  max(0.0001, 1e-6 × largest lot)). Otherwise it logs a warning and keeps
  the old ledger.
- Transactions take an optional `currency` and
  `amount_in_account_currency`.
- Reconnecting (new form values) keeps the connection's `state`.

From Trading 212 (https://docs.trading212.com/api):

- Hosts: `live.trading212.com` and `demo.trading212.com`, paths under
  `/api/v0`.
- Auth: HTTP Basic, username = API key, password = API secret.
- Rate limits are per account (shared with anything else the person runs
  against that account) and come back in `x-ratelimit-*` headers. Relevant
  ones: account summary 1/5 s, positions 1/1 s, instruments metadata 1/50 s,
  history orders/dividends/transactions 20/min each.
- History endpoints page with `limit` (max 50) and `cursor`; the response
  gives `nextPagePath` (use as-is, `null` when done).
- The API is beta (v0).

## Approaches considered

| | Approach | Trade-off |
|---|---|---|
| **A (chosen)** | **Live JSON API.** Summary and positions every sync; orders, dividends and transactions paged, with cursors kept in state. | Structured data, only the two API hosts needed. Long histories take several syncs to backfill because of the 20 req/min limits and the 60 s call limit. |
| B | CSV export (request report, poll, download), like IBKR's Flex flow. | One file with everything, including FX conversions. But undocumented CSV columns, 1 request per 30–60 s, and the download link's host is undocumented — if it varies, it can't be declared in the manifest, which could block the plugin outright. |
| C | Snapshot only (summary + positions). | Simplest, instant. No trades, dividends or gains history. |

The person picked **A**.

## Design

### Manifest

- `id`: `<owner>/securo-trading212` (owner = the GitHub account it's
  published under; placeholder until known).
- One integration, key `api`, `auth: "credentials"`, `sync_minutes: 60`,
  `provides: ["accounts", "transactions", "holdings", "trades"]`.
- Fields:
  - `api_key` — "API key", `secret: true` (it's half of the Basic auth
    credential, so it's stored encrypted like the secret).
  - `api_secret` — "API secret", `secret: true`.
  - `environment` — "Environment (live or demo)", `required: false`,
    defaults to `live`. Anything other than `live`/`demo` → `NeedsAuth`.
- `network`: `live.trading212.com`, `demo.trading212.com`, each with a
  purpose string.
- No `api_scopes`: the plugin writes nothing through Securo's REST API; it
  returns records.
- English strings only (the IBKR plugin also ships pt-BR; not needed here).

### What a sync returns

**One account** per connection (T212 accounts have one currency):

- `external_id`: `t212:<accountId>` (accountId from the account summary).
- `name`: `Trading 212 (<CCY>)`; `masked_number`: last 4 of the account id;
  `type: "investment"`; `institution_logo: "trading212"`.
- `balance`: total cash = `cash.availableToTrade + cash.inPies +
  cash.reservedForOrders`.
- `transactions`: cash activity, positive amounts with `credit`/`debit`:
  - From `/equity/history/transactions`: DEPOSIT and INTEREST_ON_FREE_CASH /
    LENDING_INTEREST → credit; WITHDRAW and FEE → debit; TRANSFER → by the
    sign of `amount`. External id `t212:<accountId>:txn:<reference>`.
    Payee "Trading 212".
  - From `/equity/history/dividends`: credit, amount in account currency,
    payee = instrument name, description mentions the instrument name and
    dividend type (`Dividend: <name> (<TYPE>)`). External id
    `t212:<accountId>:div:<reference>`.
  - Buys and sells are **not** cash transactions (they belong to holdings),
    matching IBKR's choice. The balance still comes straight from T212.
  - Every transaction carries its own `currency` field. The API says
    transaction amounts are "in the currency of the transaction", so an item
    in another currency is sent as-is in that currency, with
    `amount_in_account_currency` left out (the API gives no rate). Never
    relabel a foreign amount as the account currency.

**One holding per instrument**, keyed by T212 ticker (e.g. `AAPL_US_EQ`):

- `external_id`: `t212:<accountId>:<ticker>`.
- From `/equity/positions`: `quantity`, `current_value` =
  `walletImpact.currentValue`, `unit_price` = current value / quantity,
  `purchase_price` = `walletImpact.totalCost`, `isin`, `name`,
  `ticker` (the short symbol, e.g. `AAPL`), `purchase_date` = `createdAt`.
- **Currency: the account currency** for the holding and its trades, using
  T212's wallet-impact figures, so values add up with the cash account and
  gains are in what the person actually paid. Instrument-currency prices go
  into `metadata`.
- `type`: from instruments metadata — ETF → `etf`, STOCK → `stock`,
  CRYPTO/CRYPTOCURRENCY → `crypto`, anything else → `investment`.
- `trades`: one per fill from `/equity/history/orders` with
  `fill.type == TRADE`; `kind` from `order.side`; `quantity` = fill
  quantity; `fee` = sum of `fill.walletImpact.taxes`, each converted to the
  account currency with `fill.walletImpact.fxRate` when its currency
  differs; `price` = (|`netValue`| − fee for a buy, + fee for a sell) ÷
  quantity, i.e. the account-currency price excluding fees. Whether
  `netValue` includes the taxes, and which way `fxRate` points, must be
  confirmed against real responses (see "Verification"). External id
  `t212:<accountId>:fill:<fill.id>`.
- Instruments sold out are holdings with quantity 0 and their trades; they
  are remembered in `state["closed"]` and listed again every sync with
  `trades: null` (IBKR's D16), except that new fills and the balancing
  trades below are still sent (amended after review).
- **When trades don't add up to the position** (shares transferred in,
  history from before the API's reach, corporate actions), on **every**
  sync, not just the first:
  - missing units → an opening buy `t212:<accountId>:opening:<ticker>`
    dated the day before the first known trade (before the position's
    `createdAt` when there are no fills), its held-units part priced at
    the residual cost and its sold-before-history part at the last cost
    per unit (amended after review, see below);
  - surplus units (trades say more than held, e.g. a transfer out) → an
    adjustment sell `t212:<accountId>:adjust:<ticker>` dated the sync day,
    priced at the current unit value; it keeps its date only while its
    quantity is unchanged.
  Both are recomputed from scratch and resent every sync under the same
  ids; Securo overwrites them because the reported trade wins. One that
  was sent and is no longer needed is resent at 0.000001, since leaving it
  out can't delete it. They live in `state["ledger"]` so closed holdings
  keep them. This replaces IBKR's "first statement only" rule (D21),
  because Securo now allows corrections by id.
- Non-TRADE fills (stock splits, stock dividends, spin-offs, acquisitions)
  change quantities. ~~First version: map them to buys/sells at their fill
  price when they have a quantity.~~ Amended after review: they are
  skipped, and the opening-buy rule covers the gap at the residual cost
  (`walletImpact.totalCost` minus the average-cost basis of the fill lots
  still held, spread over the held units no fill explains), so a split's
  extra shares cost 0 and transferred-in shares their real cost. Their
  quantity semantics are undocumented and mapping them as well could count
  units twice. **Must be checked against a real account (demo key) before
  release.**

### Sync flow and state

Every sync:

1. Read credentials; validate; build the Basic auth header.
2. `GET /equity/account/summary` → account id, currency, cash.
3. `GET /equity/positions` → open positions.
4. Instrument types: kept in `state["types"]` (ticker → type). Only when a
   ticker isn't known yet, and at most once per 24 h, call
   `/equity/metadata/instruments` once and fill the cache.
5. History: advance each of `orders`, `dividends`, `transactions` as far as
   the time budget (~40 s of the 60 s) and rate-limit headers allow, saving
   cursors in state.
6. Build and return the payload.

History has two phases per endpoint, tracked in `state["history"][<endpoint>]`:

- **Backfill**: walk pages from newest to oldest until `nextPagePath` is
  null, keeping the next path in state. Collected-but-not-yet-sent fills
  are kept in state in a compact form (id, ticker, side, date, quantity,
  price, fee).
- **Incremental**: after backfill, each sync reads from the newest page
  until it reaches items it already has (newest seen id/time stored in
  state), then stops.

**Holdings and trades are only sent once the orders backfill is complete**,
because before then trades can't add up and the opening-buy maths would be
wrong. Until then `data` carries the account (balance + cash activity
collected so far) with `holdings` left out (`null`), which Securo treats as
"not fetched" and leaves alone — so a backfill never archives anything.

Securo only stores a holding's trades once they add up, so fills collected
during backfill are kept in state (compact: ~100 bytes each, so ~1 MB per
10,000 fills, well under the 16 MB reply cap). After the first full holdings
payload is written, the state keeps only what later syncs need: per
holding, the running quantity from trades sent so far (to recompute the
opening/adjust trades) — not every fill.

If one reply would exceed 20,000 trades, spread them over consecutive
syncs: holdings beyond the budget go with `trades: null` (ledger untouched)
and get theirs next time. Every holding is still listed every time.

Cash activity is sent as it is collected (Securo dedups by id), so it
appears during backfill.

### Errors

- 401 → `NeedsAuth("Trading 212 rejected the API key or secret.")`.
- 403 with a scope message → `NeedsAuth` naming the missing permission
  (e.g. "history:orders") and telling the person to edit the key.
- 429 or running out of time budget → stop paging, keep cursors, return
  what was gathered. Not a failure.
- 408 / 5xx / network errors → retryable exception with a message that
  never contains the URL with credentials, the secret, or response bodies.
- Unknown `environment` value or empty key/secret → `NeedsAuth`.

### Package layout (mirrors IBKR)

```
securo-plugin.json
pyproject.toml            # dev only: pytest
README.md                 # setup: create read-only key, connect in Securo
DESIGN.md                 # decisions with D-numbers, like IBKR
LICENSE                   # MIT
icon.png, logos/trading212.png
securo_trading212/
  plugin.py    # sync(): credentials, flow, state
  client.py    # HTTP: auth, rate-limit headers, pagination, time budget
  mapping.py   # pure: API JSON → accounts/transactions/holdings/trades
  payload.py   # contract-1 payload, number formatting, openings/closed
  errors.py    # NeedsAuth, Transient
tests/         # fake HTTP + made-up JSON fixtures
```

## Verification

No Trading 212 key (demo or live) is available during development, so
fixtures are built from the OpenAPI spec and everything that depends on
undocumented behaviour is handled conservatively:

- **Trade price and fees, self-checking.** For each fill, compute the
  account-currency price two ways — `fill.price` × `fxRate` and
  `fill.price` ÷ `fxRate` — and pick the one within 2% of
  |`netValue`| ÷ quantity. Use the same match to decide whether `netValue`
  already includes the taxes (with vs without fees, whichever matches
  better). If nothing matches, use |`netValue`| ÷ quantity, leave fees out
  of the price, and log a warning. When `fxRate` is missing or 1 and the
  currencies are equal, no conversion.
- **Unknown values** (new transaction types and fill types; dividend
  types and order statuses aren't checked as built): logged to stderr (which ends up in the plugin-runner
  log) with the type name only — never amounts, ids, tickers or
  credentials. Unknown cash types are sent with the sign of `amount`.
  Unknown fill types are skipped, and the opening/adjust rule covers the
  gap.
- **Pagination order** isn't documented (newest-first is assumed). The
  incremental phase stops on the first already-seen id; the backfill
  doesn't depend on order, only on `nextPagePath` becoming `null`.
- **Release as 0.1.0, marked beta** in the README, which asks people to
  report mismatched positions or gains. The person's first real sync after
  installing is the real-data check.

## Amendments after review

Recorded after the final whole-branch review (2026-11-21); DESIGN.md
D14, D15, D25–D27 hold the detail.

- **F1 — balancing trades recomputed from scratch.** The opening buy and
  adjustment sell were only ever grown, so a temporary mismatch (history
  lagging the positions, a positions glitch, a fill missed by the
  incremental stop) left a permanent fake buy and sell with made-up gains.
  Now both are sized afresh every sync; one already sent and no longer
  needed is kept at 0.000001 (Securo can't delete it by omission, and that
  is well within its tolerance). Differences of 0.00001 or less count as
  matched. The adjustment sell keeps its date and price only while its
  quantity is unchanged; when its quantity changes, or a sell dated on or
  before its date arrives, it moves to the sync day, the one date where it
  always replays without going below zero. (Second review: keeping the
  date while it shrank was refused by Securo when lagging fills landed on
  or before that date.)
- **Late fills replayed by date.** A fill can arrive a sync late, dated
  before fills already applied. Each ticker's ledger keeps its net
  quantity change per fill date, and the lowest running quantity is
  replayed from it: the lowest end-of-day total, since Securo replays a
  day's buys first. A late fill then lands in its place, and once every
  fill is in, the opening and adjustment sell shrink back to 0.000001.
  (Second review: a low tracked in arrival order let a shrinking opening
  fall below the real dip, and Securo refused the ledger or replaced it
  with the reported trades alone. Third review: a low that only went
  down, the second round's fix, left a permanent opening and adjustment
  sell with a made-up gain after any late sell.)
- **F2 — closed tickers priced from what was last seen.** Each ticker's
  last cost and value per unit are kept in state while it is open. For a
  ticker no longer in the positions, the adjustment sell uses the last
  value per unit (else the average sell price) and the opening buy the
  last cost per unit (else the price of the sells that took the quantity
  below zero), instead of 0.
- **F3 — non-TRADE fills skipped; opening priced at residual cost.** See
  the amended bullet under "One holding per instrument". The opening has
  two parts: the dip (`-low`, units sold before any were bought) priced by
  the F2 rule, and the shortfall (`target - (net - low)`, held units no
  fill explains) at the residual cost, `totalCost` minus the average-cost
  basis of the held fill lots (`net - low` units). One opening is sent at
  their quantity-weighted price. (Second review: pricing the whole
  opening at the residual cost made up gains when units sold before the
  history were bought back.)

## Decided by the person

- Trading 212 accounts, read-only sync.
- Approach A (live JSON API).
- No Trading 212 key available for development (see Verification).

## Calls made by me (correct me)

- Full history on the first sync (no 365-day cap like IBKR): T212 has no
  statement window, and full history is what makes trades add up.
- Account currency for holdings and trades.
- Buys/sells excluded from cash activity.
- `environment` field to allow demo keys (useful for testing safely).
- Holding keyed by T212 ticker, not ISIN (one ISIN can trade on several
  exchanges under different tickers).
- `sync_minutes: 60`.
- Opening buy / adjustment sell recomputed on every sync (not first-only
  like IBKR).
- Foreign-currency cash items sent in their own currency.
- Spreading trades over syncs if a reply would exceed 20,000.
- The self-checking price/fee rule and logging unknown types, since no
  key is available.
- Version 0.1.0, beta.

## Left to the builder

- Exact time budget and page counts per endpoint per call.
- How to order the three history endpoints within one call.
- Compact state encoding.
- Test structure and fixture shapes (from the OpenAPI spec).
- README wording and screenshots.
- Icon/logo artwork (must be original or properly licensed; no
  Trading 212 trademarks beyond what's needed to name the service).
