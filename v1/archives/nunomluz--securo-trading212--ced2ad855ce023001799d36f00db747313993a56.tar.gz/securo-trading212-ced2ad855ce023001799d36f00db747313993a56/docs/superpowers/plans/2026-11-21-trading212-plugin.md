# Trading 212 Securo Plugin Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A Securo provider plugin that syncs one Trading 212 account per API key (cash, cash activity, holdings, trades), read-only.

**Architecture:** `sync(params, context)` reads the account summary and positions every call, walks the three history endpoints with cursors kept in `state`, and returns a provider-contract-1 payload that Securo writes and dedups by `external_id`. Pure mapping/ledger code is separated from HTTP so almost everything is unit-tested against made-up JSON.

**Tech Stack:** Python standard library only (runtime 3.14, code must also run on the local 3.13), pytest for tests.

**Spec:** `docs/superpowers/specs/2026-11-21-trading212-plugin-design.md` — read it before starting any task.

## Global Constraints

- Standard library only in `securo_trading212/`; no lockfile. Syntax must work on Python 3.13 (local) and 3.14 (runner).
- Entry point `securo_trading212.plugin:plugin`; `min_securo_version` `0.20.0`; version `0.1.0`.
- Hosts: `live.trading212.com`, `demo.trading212.com`; API prefix `/api/v0`. No other host is ever contacted; `nextPagePath` is only ever used as a path on the same host.
- Auth: `Authorization: Basic base64("<api_key>:<api_secret>")`.
- Whole call ≤ 60 s; the client's time budget is **40 s** (`BUDGET_SECONDS = 40`).
- Amounts leave the plugin as strings from `numbers.number()`: ≤ 8 decimals, no exponent, never floats.
- Reply caps: ≤ 20,000 trades and ≤ 20,000 transactions per reply (`MAX_TRADES = 20_000`, `MAX_TRANSACTIONS = 20_000`).
- External-id formats (frozen once released):
  - account `t212:<accountId>`
  - cash transaction `t212:<accountId>:txn:<reference>`
  - dividend `t212:<accountId>:div:<reference>`
  - holding `t212:<accountId>:<ticker>` (T212 ticker, e.g. `AAPL_US_EQ`)
  - trade `t212:<accountId>:fill:<fillId>`
  - opening buy `t212:<accountId>:opening:<ticker>`
  - adjustment sell `t212:<accountId>:adjust:<ticker>`
- Never put the API key, secret, URLs with credentials, response bodies, amounts, ids or tickers in exception messages or logs. Logs name only enum-like type names (`[A-Z0-9_]`, ≤ 40 chars) or fixed messages.
- All test fixtures are made up (no real account ids, amounts or holdings).
- Securo semantics: a list left out/`null` = "not fetched, leave alone"; `holdings: []` archives everything, so **never send `[]` for holdings** unless the account truly has no holdings and the orders backfill is complete. `trades: null` on a holding leaves its ledger alone.
- Commit messages end with `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`.

## Review Focus

- Key reconnected to a *different* T212 account (summary `id` ≠ `state["account_id"]`): expect state reset and a fresh backfill, never mixing two accounts' records → test in Task 8.
- Rate limit hit mid-backfill (429 or `x-ratelimit-remaining: 0` with a far reset): expect sync to succeed with progress kept in `state`, not an error → tests in Tasks 2 and 5.
- `nextPagePath` pointing at another host or a scheme (`https://evil.example/...`, `//evil.example`): expect `Transient`, no request made → test in Task 2.
- Position sold out between syncs (ticker in ledger, absent from positions): expect a quantity-0 holding listed on this and every later sync, never dropped → test in Task 7.
- Cash item in a currency other than the account's: expect it sent with its own `currency`, never relabelled → test in Task 3.

---

## File Structure

```
.gitignore
pyproject.toml                 # dev only: pytest
securo-plugin.json             # manifest
README.md  DESIGN.md  LICENSE  icon.png  logos/trading212.png
tools/make_icons.py            # stdlib PNG generator for icon.png and the logo
securo_trading212/
  __init__.py
  errors.py     # NeedsAuth, Transient, RateLimited, OutOfTime
  numbers.py    # parse_decimal, number
  log.py        # reset, unknown, warning (stderr, values never logged)
  client.py     # HTTP: auth, status mapping, rate limits, time budget, path checks
  mapping.py    # pure: JSON items -> CashTxn / Fill; asset types; symbols
  history.py    # cursor walking per endpoint (backfill / incremental)
  ledger.py     # running quantity per ticker; opening/adjust trades
  payload.py    # contract-1 dicts: account, holdings, trade budget, closed holdings
  plugin.py     # sync(): orchestration and state
tests/
  __init__.py
  factories.py  # made-up T212 JSON builders + FakeHttp
  test_numbers.py test_client.py test_mapping_cash.py test_mapping_fills.py
  test_history.py test_ledger.py test_payload.py test_plugin.py test_manifest.py
```

Run tests from the repo root with `python -m pytest -q`.

---

### Task 1: Scaffold, errors, numbers, log

**Files:**
- Create: `.gitignore`, `pyproject.toml`, `securo_trading212/__init__.py`, `securo_trading212/errors.py`, `securo_trading212/numbers.py`, `securo_trading212/log.py`, `tests/__init__.py`, `tests/test_numbers.py`

**Interfaces:**
- Produces:
  - `errors.NeedsAuth(message: str, *, code: str = "credentials_invalid")` — message gets `" Help: " + HELP_URL` appended; `.code` attribute. `HELP_URL = "https://helpcentre.trading212.com/hc/en-us/articles/14584770928157-Trading-212-API-key"`.
  - `errors.Transient(Exception)` — retryable failure.
  - `errors.RateLimited(Exception)`, `errors.OutOfTime(Exception)` — internal signals, never escape `sync`.
  - `numbers.parse_decimal(value: object) -> Decimal | None` — accepts `Decimal`, `int`, numeric `str`; `None`, `""`, `bool`, non-numeric, NaN/Inf → `None`.
  - `numbers.number(value: Decimal) -> str` — quantize to 8 places (ROUND_HALF_UP), strip trailing zeros, fixed-point, `-0` → `"0"`.
  - `log.reset() -> None`, `log.unknown(kind: str, name: object) -> None` (prints once per `(kind, safe_name)` per sync: `trading212: unknown <kind>: <SAFE>` to stderr, SAFE = uppercase `[A-Z0-9_]` only, ≤ 40 chars, `?` if empty), `log.warning(message: str) -> None` (prints `trading212: <message>` once per message per sync; callers pass fixed text only).

- [ ] **Step 1: Write scaffolding**

`pyproject.toml`: project `securo-trading212`, version `0.1.0`, `requires-python = ">=3.13"`, `dependencies = []`, dependency-group `dev = ["pytest>=8"]`, `[tool.pytest.ini_options] testpaths = ["tests"]`, `pythonpath = ["."]`. Top comment: `# Development only. The plugin itself uses the standard library and ships no lockfile.` `.gitignore`: `__pycache__/`, `.pytest_cache/`, `.venv/`, `site/`, `*.egg-info/`, `captures/`.

- [ ] **Step 2: Write the failing tests** in `tests/test_numbers.py`

```python
from decimal import Decimal
import pytest
from securo_trading212.numbers import number, parse_decimal
from securo_trading212 import log

@pytest.mark.parametrize("raw,expected", [
    (Decimal("1.50"), "1.5"), (Decimal("10"), "10"), (Decimal("1E+2"), "100"),
    (Decimal("0.123456789"), "0.12345679"), (Decimal("-0.000000001"), "0"),
    (Decimal("-2.5"), "-2.5"),
])
def test_number(raw, expected):
    assert number(raw) == expected

@pytest.mark.parametrize("raw,expected", [
    ("12.30", Decimal("12.30")), (7, Decimal(7)), (Decimal("1.1"), Decimal("1.1")),
    (None, None), ("", None), (True, None), ("abc", None), ("NaN", None), ("Infinity", None),
])
def test_parse_decimal(raw, expected):
    assert parse_decimal(raw) == expected

def test_unknown_logs_once_and_sanitises(capsys):
    log.reset()
    log.unknown("transaction type", "new_type<script>")
    log.unknown("transaction type", "new_type<script>")
    err = capsys.readouterr().err
    assert err.count("trading212: unknown transaction type: NEW_TYPESCRIPT") == 1
```

- [ ] **Step 3: Run** `python -m pytest tests/test_numbers.py -q` — expect FAIL (`ModuleNotFoundError`).
- [ ] **Step 4: Implement** `errors.py`, `numbers.py`, `log.py` per the Interfaces block.
- [ ] **Step 5: Run** `python -m pytest -q` — expect all PASS.
- [ ] **Step 6: Commit** `git add -A && git commit -m "feat: scaffold package with errors, numbers and log"` (with the Co-Authored-By trailer).

---

### Task 2: HTTP client

**Files:**
- Create: `securo_trading212/client.py`, `tests/factories.py`, `tests/test_client.py`

**Interfaces:**
- Consumes: `errors.*` (Task 1).
- Produces:
  - `client.HOSTS = {"live": "live.trading212.com", "demo": "demo.trading212.com"}`, `API_PREFIX = "/api/v0"`, `BUDGET_SECONDS = 40`, `HTTP_TIMEOUT = 15`, `MAX_RESPONSE_BYTES = 32 * 1024 * 1024`.
  - `Http = Callable[[str, dict[str, str]], tuple[int, dict[str, str], bytes]]` — `(url, request_headers) -> (status, lowercased response headers, body)`; raises `OSError` on transport failure.
  - `client.urllib_get(url, headers)` — urllib, **no redirects**, timeout `HTTP_TIMEOUT`, reads at most `MAX_RESPONSE_BYTES + 1` (more → `Transient`), `HTTPError` → its status/headers and ≤ 4 KB of body.
  - `class Client(*, api_key: str, api_secret: str, environment: str | None, http: Http = urllib_get, clock=time.monotonic, wall=time.time, sleep=time.sleep, budget: float = BUDGET_SECONDS)` with `get(path: str) -> Any` and `remaining() -> float`.
  - `tests.factories.FakeHttp(routes: dict[str, list[Reply]])` with `Reply = tuple[int, dict, object]` (status, headers, body as JSON-able object or `bytes`); matches on the URL's path+query, falling back to the path alone; pops replies in order, repeating the last; records `calls: list[tuple[str, dict]]`. Unrouted URL → `AssertionError`.

Client behaviour (each is a test below):
- Constructor: environment `None`/blank → `"live"`; lowercased; not in `HOSTS` → `NeedsAuth(..., code="environment_invalid")`. Empty key or secret, or either > 512 chars → `NeedsAuth`.
- `get(path)`: path must start with `/`, must not start with `//`, must not contain `://` or `\` → `Transient("Trading 212 returned an unexpected page link.")` with **no** request made. Paths not starting with `/api/v0` get it prefixed. URL = `https://<host><path>`.
- `remaining() <= 0` before a request → `OutOfTime`.
- Rate limits are tracked per path without query. After each response, if `x-ratelimit-remaining == "0"`, remember `x-ratelimit-reset` (unix seconds) for that path. Before a request to a blocked path: `wait = reset - wall()`; if `wait <= remaining() - 2` sleep `max(wait, 0) + 0.5`, else raise `RateLimited`.
- 429 → mark the path blocked until `x-ratelimit-reset` (or `wall() + 60` when absent), then apply the rule above once more (sleep-and-retry once, or `RateLimited`).
- 401 → `NeedsAuth("Trading 212 rejected the API key or secret.")`.
- 403 → look for `Scope\(\s*([A-Za-z:_]+)\s*\)` in the first 2 KB of the body: found → `NeedsAuth(f"The API key is missing the \"{scope}\" permission. Edit the key in Trading 212 and enable it.", code="permission_missing")`; else `NeedsAuth("The API key isn't allowed to read this. Edit the key's permissions in Trading 212.", code="permission_missing")`.
- `OSError` → `Transient(f"Couldn't reach Trading 212 ({type(exc).__name__}).")`; any other non-200 → `Transient(f"Trading 212 answered HTTP {status}.")`.
- 200 → `json.loads(body, parse_float=Decimal)`; failure → `Transient("Trading 212 returned an unreadable response.")`.

- [ ] **Step 1: Write `tests/factories.py`** with `FakeHttp` (per Interfaces) and these builders, all made-up values, numbers as `int`/`float`:
  - `summary(id=10000001, currency="EUR", available=100.5, in_pies=0, reserved=0)`
  - `position(ticker="AAPL_US_EQ", name="Apple", isin="US0378331005", currency="USD", quantity=2, value=300, cost=250, avg=140.0, price=170.0, created="2024-01-02T10:00:00Z", in_pies=0)` → Position JSON with nested `instrument` and `walletImpact`
  - `order(fill_id, ticker="AAPL_US_EQ", side="BUY", quantity=1, price=100.0, net=-100.0, fx=1.0, taxes=(), filled="2024-01-02T10:00:00Z", fill_type="TRADE", currency="USD", name="Apple", isin="US0378331005")` → `{"order": {...}, "fill": {...}}`; `taxes` items `(name, quantity, currency)`
  - `dividend(reference, ticker="AAPL_US_EQ", amount=1.2, currency="EUR", paid="2024-03-01T00:00:00Z", name="Apple", type="ORDINARY")`
  - `transaction(reference, type="DEPOSIT", amount=500, currency="EUR", when="2024-01-01T09:00:00Z")`
  - `page(items, next_path=None)` → `{"items": items, "nextPagePath": next_path}`
  - `instrument_meta(ticker, type="STOCK", short="AAPL", name="Apple", currency="USD", isin=...)`
  - `ok(body, remaining="10", reset="0")` → `(200, {"x-ratelimit-remaining": remaining, "x-ratelimit-reset": reset}, body)`

- [ ] **Step 2: Write the failing tests** in `tests/test_client.py`, using a fake clock/wall/sleep (`now = [0.0]`, `wall = [1_700_000_000.0]`; `sleep` advances both):

```python
def test_basic_auth_and_prefix():            # get("/equity/account/summary") -> calls[0] url == "https://live.trading212.com/api/v0/equity/account/summary"; Authorization == "Basic " + b64("k:s")
def test_demo_environment_host():            # environment="DEMO" -> host demo.trading212.com
def test_bad_environment_needs_auth():       # environment="paper" -> NeedsAuth, .code == "environment_invalid"
def test_missing_secret_needs_auth():        # api_secret="  " -> NeedsAuth
@pytest.mark.parametrize("path", ["https://evil.example/x", "//evil.example/x", "/a\\b", "equity/x"])
def test_foreign_page_link_refused(path):    # Transient, http.calls == []
def test_401_needs_auth():
def test_403_names_scope():                  # body b'{"message":"Scope( history:orders ) missing for API key"}' -> "history:orders" in str(exc), code "permission_missing"
def test_403_without_scope():                # generic permission message
def test_500_transient_without_body():       # body b"SECRET-ish text" -> Transient, "SECRET" not in str(exc)
def test_oserror_transient():                # http raises ConnectionResetError -> "Couldn't reach Trading 212 (ConnectionResetError)."
def test_decimal_parsing():                  # body {"cash": 0.1} -> result["cash"] == Decimal("0.1")
def test_waits_for_short_rate_limit():       # first reply remaining "0", reset wall+5 -> second get sleeps ~5.5 and succeeds
def test_rate_limited_when_reset_beyond_budget():  # reset wall+120 -> second get raises RateLimited, only 1 call made
def test_429_retries_once_then_rate_limited():     # 429 with reset wall+3, then 200 -> success after one sleep; 429 with reset wall+600 -> RateLimited
def test_out_of_time():                      # advance clock past budget -> OutOfTime, no call
def test_secret_never_in_messages():         # for 401/403/500/OSError cases: api_key/api_secret strings not in str(exc)
```

- [ ] **Step 3: Run** `python -m pytest tests/test_client.py -q` — expect FAIL.
- [ ] **Step 4: Implement** `client.py` per Interfaces.
- [ ] **Step 5: Run** `python -m pytest -q` — expect PASS.
- [ ] **Step 6: Commit** `feat: add Trading 212 HTTP client with rate limits and time budget`.

---

### Task 3: Cash activity mapping

**Files:**
- Create: `securo_trading212/mapping.py`, `tests/test_mapping_cash.py`

**Interfaces:**
- Consumes: `numbers.parse_decimal`, `log.unknown`, `log.warning`.
- Produces:
  - `@dataclass(frozen=True) class CashTxn: external_id: str; description: str; amount: Decimal; date: date; type: str; currency: str; payee: str` (`amount` always > 0; `type` `"credit"`/`"debit"`).
  - `cash_from_transaction(item: dict, account_id: str) -> CashTxn | None`
  - `cash_from_dividend(item: dict, account_id: str) -> CashTxn | None`
  - `iso_date(value: object) -> date | None` — date part of an ISO date-time (`Z` accepted), converted to UTC first when it has an offset.

Rules:
- Transactions: `DEPOSIT`, `INTEREST_ON_FREE_CASH`, `LENDING_INTEREST` → credit; `WITHDRAW`, `FEE` → debit; `TRANSFER` and unknown types → sign of `amount` (unknown also `log.unknown("transaction type", type)`). Amount = `abs(amount)`. Descriptions: `Deposit`, `Withdrawal`, `Fee`, `Interest on cash`, `Share lending interest`, `Transfer`, fallback `Trading 212 cash movement`. Payee `Trading 212`. Currency = item `currency` uppercased; must match `^[A-Z]{3}$`.
- Dividends: credit when `amount > 0`, debit when `< 0`. Currency = item `currency`. Description `f"Dividend: {instrument name or ticker}"`[:500]; payee = instrument name or ticker [:200].
- Return `None` (and `log.warning("skipped a cash item without a reference, date, amount or currency")`) when reference, date, amount or currency is missing/invalid, or amount is 0.

- [ ] **Step 1: Write the failing tests**

```python
def test_deposit_is_credit():        # transaction("r1","DEPOSIT",500) -> CashTxn("t212:10000001:txn:r1","Deposit",Decimal("500"),date(2024,1,1),"credit","EUR","Trading 212")
def test_withdraw_negative_amount_is_debit():   # amount=-200 -> amount Decimal("200"), "debit"
def test_fee_is_debit():
def test_interest_is_credit():       # INTEREST_ON_FREE_CASH and LENDING_INTEREST
def test_transfer_follows_sign():    # -50 -> debit, 50 -> credit
def test_unknown_type_follows_sign_and_logs(capsys):  # type "CASHBACK", amount 3 -> credit; stderr has "unknown transaction type: CASHBACK"; "3" amount not in stderr
def test_foreign_currency_kept():    # currency "USD" on EUR account -> CashTxn.currency == "USD"
def test_missing_reference_skipped():  # reference None -> None
def test_zero_amount_skipped():
def test_dividend():                 # dividend("d1", amount=1.2) -> "t212:10000001:div:d1", "Dividend: Apple", payee "Apple", credit, date(2024,3,1)
def test_negative_dividend_is_debit():
def test_iso_date_offset_to_utc():   # "2024-01-01T23:30:00-02:00" -> date(2024,1,2)
```

- [ ] **Step 2: Run** `python -m pytest tests/test_mapping_cash.py -q` — expect FAIL.
- [ ] **Step 3: Implement** per Interfaces.
- [ ] **Step 4: Run** `python -m pytest -q` — expect PASS.
- [ ] **Step 5: Commit** `feat: map Trading 212 transactions and dividends to cash activity`.

---

### Task 4: Fill mapping with self-checking price and fees

**Files:**
- Modify: `securo_trading212/mapping.py`
- Create: `tests/test_mapping_fills.py`

**Interfaces:**
- Consumes: Task 3 helpers.
- Produces:
  - `@dataclass(frozen=True) class Fill: id: str; ticker: str; date: date; kind: str; quantity: Decimal; price: Decimal; fee: Decimal` with `to_state() -> list` (`[id, ticker, date iso, kind, number(q), number(p), number(f)]`) and `@classmethod from_state(row: list) -> Fill`.
  - `fill_from_order(item: dict, account_currency: str) -> Fill | None`
  - `instrument_info(instrument: dict) -> dict` → `{"name": str, "isin": str | None}` (isin only when it matches `^[A-Z]{2}[A-Z0-9]{9}[0-9]$`).
  - `asset_type(t212_type: str | None) -> str | None` — `STOCK`→`stock`, `ETF`→`etf`, `CRYPTO`/`CRYPTOCURRENCY`→`crypto`, any other non-empty → `investment`, `None` → `None`.
  - `short_symbol(ticker: str, short_name: str | None) -> str` — `short_name` when given, else the part of `ticker` before the first `_`; truncated to 32.

`fill_from_order` rules: return `None` when `fill` is missing, `fill.type != "TRADE"` (non-`TRADE` types call `log.unknown("fill type", type)` only when not in the spec's known list: `STOCK_SPLIT, STOCK_DISTRIBUTION, FOP, FOP_CORRECTION, CUSTOM_STOCK_DISTRIBUTION, EQUITY_RIGHTS, SCRIP_STOCK_DIVIDENDS, STOCK_DIVIDENDS, STOCK_ACQUISITION, CASH_AND_STOCK_ACQUISITION, SPIN_OFF`), quantity ≤ 0 after `abs`, or side not `BUY`/`SELL`. `id = str(fill.id)`; `ticker = order.ticker or order.instrument.ticker`; date from `fill.filledAt`; kind from side.

Price and fee (algorithm the tests don't fully determine — implement exactly):

```python
def _price_and_fee(fill: dict, quantity: Decimal, kind: str, instrument_ccy: str | None, account_ccy: str) -> tuple[Decimal, Decimal]:
    wallet = fill.get("walletImpact") or {}
    raw_price = parse_decimal(fill.get("price")) or Decimal(0)
    net = parse_decimal(wallet.get("netValue"))
    fx = parse_decimal(wallet.get("fxRate"))
    # Fees: taxes in the account currency count as-is; others go through fx (direction found below).
    taxes = [(parse_decimal(t.get("quantity")) or Decimal(0), (t.get("currency") or "").upper())
             for t in wallet.get("taxes") or []]
    same = [abs(q) for q, c in taxes if c in ("", account_ccy)]
    other = [abs(q) for q, c in taxes if c not in ("", account_ccy)]
    if net is None or net == 0:
        log.warning("a trade had no net value; used its instrument price")
        return raw_price, sum(same, Decimal(0))
    gross_per_unit = abs(net) / quantity
    # Candidate conversions of the instrument price into the account currency.
    candidates = {"same": raw_price}
    if fx and fx > 0 and instrument_ccy and instrument_ccy != account_ccy:
        candidates = {"mul": raw_price * fx, "div": raw_price / fx}
    def convert(q: Decimal, key: str) -> Decimal:
        return q * fx if key == "mul" else q / fx if key == "div" else q
    fee_by = {k: sum(same, Decimal(0)) + sum((convert(q, k) for q in other), Decimal(0)) for k in candidates}
    best = None  # (relative error, key, net_includes_fees)
    for key, price in candidates.items():
        if price <= 0:
            continue
        for includes in (True, False):
            fee = fee_by[key]
            expected = price * quantity + (fee if kind == "buy" else -fee) if includes else price * quantity
            error = abs(abs(net) - expected) / expected if expected else None
            if error is not None and (best is None or error < best[0]):
                best = (error, key, includes)
    if best is None or best[0] > Decimal("0.02"):
        log.warning("a trade's price didn't match its net value; used net value per unit without fees")
        return gross_per_unit, Decimal(0)
    _, key, includes = best
    fee = fee_by[key]
    if not includes:
        return gross_per_unit, fee
    per_unit = (abs(net) - fee) / quantity if kind == "buy" else (abs(net) + fee) / quantity
    return max(per_unit, Decimal(0)), fee
```

- [ ] **Step 1: Write the failing tests**

```python
def test_buy_same_currency_net_includes_fee():
    # EUR instrument on EUR account: price 10, qty 3, taxes [("CURRENCY_CONVERSION_FEE", 0.15, "EUR")], net -30.15
    # -> Fill(kind="buy", quantity=3, price=Decimal("10"), fee=Decimal("0.15"))
def test_sell_same_currency_net_after_fee():
    # SELL qty 2 price 50, fee 0.10 EUR, net 99.90 -> price Decimal("50"), fee Decimal("0.10")
def test_fx_rate_multiplies():
    # USD instrument, EUR account, price 100, fx 0.9, qty 1, no taxes, net -90 -> price Decimal("90"), fee 0
def test_fx_rate_divides():
    # USD instrument, EUR account, price 100, fx 1.1111111, qty 1, net -90 -> abs(price - 90) < Decimal("0.001")
def test_foreign_currency_tax_converted():
    # USD instrument, EUR account, fx 0.9, price 100, qty 1, taxes [("FINRA_FEE", 0.5, "USD")], SELL, net 89.55 -> fee Decimal("0.45"), price Decimal("90")
def test_mismatch_falls_back_and_warns(capsys):
    # price 100, qty 1, net -50 -> price Decimal("50"), fee 0, stderr has "didn't match"; "50" not in stderr
def test_non_trade_fill_skipped():          # fill_type "STOCK_SPLIT" -> None, nothing logged
def test_unknown_fill_type_logged(capsys):  # fill_type "MERGER_X" -> None, "unknown fill type: MERGER_X"
def test_no_fill_skipped():                 # {"order": {...}, "fill": None} -> None
def test_fill_state_roundtrip():            # Fill.from_state(f.to_state()) == f
def test_asset_type():                      # STOCK->stock, ETF->etf, CRYPTOCURRENCY->crypto, WARRANT->investment, None->None
def test_short_symbol():                    # ("VUSAl_EQ", None) -> "VUSAl"; ("AAPL_US_EQ", "AAPL") -> "AAPL"
def test_instrument_info_drops_bad_isin():  # isin "bad" -> isin None
```

- [ ] **Step 2: Run** `python -m pytest tests/test_mapping_fills.py -q` — expect FAIL.
- [ ] **Step 3: Implement** per Interfaces and the algorithm above.
- [ ] **Step 4: Run** `python -m pytest -q` — expect PASS.
- [ ] **Step 5: Commit** `feat: map order fills to trades with self-checking price and fees`.

---

### Task 5: History cursor walking

**Files:**
- Create: `securo_trading212/history.py`, `tests/test_history.py`

**Interfaces:**
- Consumes: `Client.get`, `errors.RateLimited`, `errors.OutOfTime`.
- Produces:
  - `ENDPOINTS = {"transactions": "/equity/history/transactions", "dividends": "/equity/history/dividends", "orders": "/equity/history/orders"}`, `PAGE_LIMIT = 50`.
  - `item_key(endpoint: str, item: dict) -> str | None` — orders: `str(fill.id)` when there's a fill else `"o" + str(order.id)`; others: `reference`.
  - `advance(client, endpoint: str, hstate: dict) -> tuple[list[dict], dict, bool]` → (items fetched this call, new hstate, complete). `hstate` keys: `phase` (`"backfill"` default / `"incremental"`), `next` (path or `None`), `newest` (key or `None`), `head` (key or `None`). Never mutates its input.

Algorithm (pagination is assumed newest-first; implement exactly):

```python
def advance(client, endpoint, hstate):
    h = dict(hstate)
    items = []
    path = h.get("next") or f"{ENDPOINTS[endpoint]}?limit={PAGE_LIMIT}"
    while True:
        try:
            page = client.get(path)
        except (RateLimited, OutOfTime):
            h["next"] = path
            return items, h, False
        page_items = page.get("items") or []
        if h.get("head") is None and page_items:
            h["head"] = item_key(endpoint, page_items[0])
        reached = False
        for item in page_items:
            if h.get("phase") == "incremental" and _seen(endpoint, item_key(endpoint, item), h.get("newest")):
                reached = True
                break
            items.append(item)
        following = page.get("nextPagePath")
        if reached or not following:
            h.update(phase="incremental", next=None, newest=h.pop("head", None) or h.get("newest"))
            return items, h, True
        path = following
        h["next"] = following
```

`_seen(endpoint, key, newest)`: `key == newest`, or for `orders` when both are all-digit strings, `int(key) <= int(newest)`.

- [ ] **Step 1: Write the failing tests** (use `FakeHttp` + `Client`)

```python
def test_backfill_walks_all_pages():
    # page1 [t3,t2] next "/api/v0/equity/history/transactions?cursor=2&limit=50", page2 [t1] next None
    # -> items refs ["t3","t2","t1"], complete True, hstate == {"phase":"incremental","next":None,"newest":"t3"}
def test_backfill_resumes_after_rate_limit():
    # page1 reply has x-ratelimit-remaining "0", reset far away -> first call: items [t3,t2], complete False,
    # hstate["next"] == page2 path, hstate["head"] == "t3", phase "backfill"
    # second call (new Client, same FakeHttp now allowing) -> items [t1], complete True, newest "t3"
def test_incremental_stops_at_newest():
    # hstate {"phase":"incremental","newest":"t3"}; page1 [t5,t4,t3,t2] next X -> items [t5,t4], newest "t5", only 1 call
def test_incremental_nothing_new():
    # page1 [t3,...] -> items [], newest stays "t3"
def test_orders_stop_on_older_numeric_id():
    # orders incremental newest "100"; page [fill 105, fill 99] -> items [105] only
def test_empty_history():
    # page {"items": [], "nextPagePath": None} -> [], complete True, newest None
def test_does_not_mutate_input():
```

- [ ] **Step 2: Run** `python -m pytest tests/test_history.py -q` — expect FAIL.
- [ ] **Step 3: Implement** `history.py`.
- [ ] **Step 4: Run** `python -m pytest -q` — expect PASS.
- [ ] **Step 5: Commit** `feat: walk Trading 212 history pages with resumable cursors`.

---

### Task 6: Ledger and balancing trades

**Files:**
- Create: `securo_trading212/ledger.py`, `tests/test_ledger.py`

**Interfaces:**
- Consumes: `mapping.Fill`, `numbers.number`.
- Produces:
  - `@dataclass class Entry: net: Decimal = 0; low: Decimal = 0; first: date | None = None; open: Decimal = 0; open_price: Decimal = 0; adjust: Decimal = 0; adjust_date: date | None = None; adjust_price: Decimal = 0` with `to_state() -> dict` (decimals via `number`, dates ISO) and `from_state(d: dict | None) -> Entry`.
  - `apply(entry: Entry, fills: list[Fill]) -> Entry` — returns a new Entry; replays `fills` sorted by `(date, kind != "buy", id)` from `entry.net`, tracking the running minimum in `low` (min of previous `low` and every running value) and the earliest date in `first`.
  - `balance(entry: Entry, target: Decimal, *, cost_price: Decimal | None, unit_price: Decimal, today: date) -> Entry` — algorithm below.
  - `balancing_trades(entry: Entry, account_id: str, ticker: str) -> list[dict]` — contract trade dicts: opening buy when `open > 0` (`external_id` `t212:<acct>:opening:<ticker>`, `kind "buy"`, `date` = `first - 1 day` (`balance` guarantees `first` is set whenever `open > 0`), `quantity number(open)`, `price number(open_price)`, `fee "0"`), adjustment sell when `adjust > 0` (`t212:<acct>:adjust:<ticker>`, `kind "sell"`, `date adjust_date`, `price number(adjust_price)`, `fee "0"`).

`balance` (sent trades can't be deleted from Securo, so `open` and `adjust` never shrink):

```python
EPSILON = Decimal("0.000001")
def balance(entry, target, *, cost_price, unit_price, today):
    e = replace(entry)
    e.open = max(e.open, -e.low)
    final = e.net + e.open - e.adjust
    if target - final > EPSILON:
        e.open += target - final
    elif final - target > EPSILON:
        e.adjust += final - target
        e.adjust_date = today
        e.adjust_price = max(unit_price, Decimal(0))
    if e.open > 0 and (e.open_price == 0 or cost_price is not None):
        e.open_price = cost_price if cost_price is not None else unit_price
    if e.open > 0 and e.first is None:
        e.first = today
    return e
```

The opening buy's date is `first - 1 day` (so it sorts before every real trade).

- [ ] **Step 1: Write the failing tests**

```python
def test_apply_tracks_net_low_first():       # buy 2 (Jan 2), sell 3 (Jan 3), buy 1 (Jan 4) -> net 0, low -1, first Jan 2
def test_apply_same_day_buys_first():        # sell 1 and buy 1 same day from 0 -> low 0
def test_balanced_needs_nothing():           # net 2, low 0, target 2 -> open 0, adjust 0, balancing_trades == []
def test_missing_units_opening_buy():        # net 2, target 5, cost 100 -> open 3, open_price 100; trade date == first - 1 day
def test_dip_below_zero_opening_buy():       # net 0, low -1, target 0 -> open 1
def test_surplus_adjust_sell():              # net 5, target 3, unit 20, today D -> adjust 2, adjust_date D, adjust_price 20
def test_open_never_shrinks():               # open 3 already, now target lower by 3 -> open stays 3, adjust 3
def test_within_epsilon_no_change():         # target - final == 0.0000001 -> nothing
def test_entry_state_roundtrip():
def test_balancing_trade_ids():              # ids "t212:10000001:opening:AAPL_US_EQ" and "t212:10000001:adjust:AAPL_US_EQ"
```

- [ ] **Step 2: Run** `python -m pytest tests/test_ledger.py -q` — expect FAIL.
- [ ] **Step 3: Implement** `ledger.py`.
- [ ] **Step 4: Run** `python -m pytest -q` — expect PASS.
- [ ] **Step 5: Commit** `feat: add trade ledger with opening and adjustment trades`.

---

### Task 7: Payload building

**Files:**
- Create: `securo_trading212/payload.py`, `tests/test_payload.py`

**Interfaces:**
- Consumes: `CashTxn`, `Fill`, `Entry`/`apply`/`balance`/`balancing_trades`, `mapping.asset_type`, `mapping.short_symbol`, `numbers.number`.
- Produces:
  - `CONTRACT = 1`, `LOGO = "trading212"`, `MAX_TRADES = 20_000`, `MAX_TRANSACTIONS = 20_000`.
  - `account_record(summary: dict, cash: list[CashTxn]) -> dict` — `external_id t212:<id>`, `name f"Trading 212 ({currency})"`, `type "investment"`, `balance number(available + in_pies + reserved)`, `currency`, `masked_number` last 4 of id, `institution_logo LOGO`, `transactions` list of `{external_id, description, amount, date, type, currency, payee}`, deduplicated by `external_id`. (One call reads at most ~2 endpoints × 20 pages × 50 = 2,000 cash items because of T212's 20/min limits, far under `MAX_TRANSACTIONS`; raise `Transient` if it is ever exceeded rather than truncating.)
  - `build_holdings(*, account_id: str, currency: str, positions: list[dict], state: dict, today: date) -> list[dict]` — reads and **mutates** `state["pending"]` (ticker → list of fill rows), `state["ledger"]` (ticker → Entry dict), `state["instruments"]` (ticker → `{"name","isin","type","short"}`), `state["closed"]` (ticker → True).

`build_holdings` rules:
- Tickers = positions' tickers ∪ `ledger` keys ∪ `pending` keys ∪ `closed` keys.
- Trade budget: go through tickers sorted; a ticker's trades are sent this call only if all of its pending fills fit in the remaining budget of `MAX_TRADES - 2 * len(tickers)` (room kept for balancing trades); otherwise `trades: null` and its pending fills stay in state. A ticker with more pending fills than the whole budget: `log.warning("an instrument has more trades than one sync can send; its trades are left out")` and `trades: null` every time.
- For a ticker sent this call: `entry = apply(Entry.from_state(...), pending fills)`, then `balance(entry, target=quantity (0 if closed), cost_price=totalCost/quantity if open and quantity > 0 else None, unit_price=currentValue/quantity if open else 0, today)`, store `entry.to_state()`, remove the ticker from `pending`. `trades` = the fills as contract trades (`external_id t212:<acct>:fill:<id>`, `kind`, `date`, `quantity`, `price`, `fee`) + `balancing_trades(...)`. A ticker with nothing pending still runs `balance` and sends its `balancing_trades` (they are resent every sync). If the combined list is empty, send `trades: null`.
- Open position record: `external_id t212:<acct>:<ticker>`, `name` (instrument name [:255]), `type` (from `instruments[ticker]["type"]`, omitted when `None`), `currency` = account currency, `current_value number(walletImpact.currentValue)`, `quantity`, `unit_price` (when quantity > 0), `purchase_price number(walletImpact.totalCost)`, `purchase_date` (date of `createdAt`), `isin` (when valid), `ticker` (`short_symbol`), `metadata {"t212_ticker", "instrument_currency", "average_price_paid", "current_price", "quantity_in_pies"}` (values as strings), and `trades`. Remove the ticker from `closed`.
- Ticker not in positions (sold out): `current_value "0"`, `quantity "0"`, name/type/isin from `instruments`, `trades` per the rules above; set `closed[ticker] = True`.

- [ ] **Step 1: Write the failing tests**

```python
def test_account_record():                 # summary(available=100.5, in_pies=20, reserved=4.5) -> balance "125", masked_number "0001", name "Trading 212 (EUR)"
def test_account_keeps_foreign_currency_txn():   # CashTxn currency "USD" -> transactions[0]["currency"] == "USD"
def test_open_position_with_matching_trades():   # pending buy 2 -> holding quantity "2", trades == [fill trade] (no opening), ledger net "2"
def test_position_without_history_gets_opening(): # no fills, position qty 2 cost 250 -> trades == [opening buy qty "2" price "125"]
def test_sold_out_listed_with_zero():      # ledger AAPL net 0, not in positions -> holding quantity "0", current_value "0", closed["AAPL_US_EQ"] True
def test_closed_listed_again_next_call():  # second call with no new fills -> still listed with quantity "0"
def test_trade_budget_defers_ticker(monkeypatch):  # MAX_TRADES=5, A has 2 pending, B has 4 -> A trades sent, B trades None, B pending kept
def test_balancing_trades_resent():        # call twice; opening buy present both times with same external_id
def test_no_trade_amount_is_float():       # every amount field in every holding/trade is a str
```

- [ ] **Step 2: Run** `python -m pytest tests/test_payload.py -q` — expect FAIL.
- [ ] **Step 3: Implement** `payload.py`.
- [ ] **Step 4: Run** `python -m pytest -q` — expect PASS.
- [ ] **Step 5: Commit** `feat: build contract-1 account and holdings records`.

---

### Task 8: `sync` orchestration

**Files:**
- Create: `securo_trading212/plugin.py`, `tests/test_plugin.py`

**Interfaces:**
- Consumes: everything above.
- Produces: `class Trading212(*, http: Http | None = None, clock=None, wall=None, sleep=None, today: Callable[[], date] | None = None)` with `sync(self, params: dict, context) -> dict`; module attribute `plugin = Trading212()`. `context` has `.secrets` (`api_key`, `api_secret`) and `.config` (`environment`).

`sync` flow:
1. `log.reset()`; `state = dict(params.get("state") or {})`; build `Client` from `context.secrets["api_key"]`, `context.secrets["api_secret"]`, `context.config.get("environment")`.
2. `summary = client.get("/equity/account/summary")`; `account_id = str(summary["id"])`, `currency = summary["currency"]`. If `state.get("account_id")` exists and differs: `log.warning("this key belongs to a different account; starting over")`, `state = {}`. Set `state["account_id"]`.
3. `positions = client.get("/equity/positions")`; record each position's `instrument_info` + short ticker into `state["instruments"]`.
4. For endpoint in `("transactions", "dividends", "orders")`: `items, h, done = advance(client, endpoint, state["history"].get(endpoint, {}))`; store `h`. Transactions/dividends → `CashTxn`s. Orders → `fill_from_order`, skipping fill ids in `state["recent_fills"]` (last 500 ids, newest last); append rows to `state["pending"][ticker]`; record order `instrument_info` into `state["instruments"]`; add ids to `recent_fills` (trim to 500). Record `state["orders_complete"] = True` once orders `done` is first True.
5. Instrument types: tickers in positions/pending with no `type` in `state["instruments"]`, and `state.get("instruments_at")` absent or older than 24 h (by `wall()`): try `client.get("/equity/metadata/instruments")` (catch `RateLimited`/`OutOfTime` → skip), set `type` via `asset_type` and `short` via `shortName` for every ticker we know; set `state["instruments_at"]`.
6. `holdings = build_holdings(...)` only when `state.get("orders_complete")`; otherwise holdings key is **left out**.
7. Return `{"state": state, "data": {"contract": 1, "accounts": [account_record(summary, cash)], **({"holdings": holdings} if orders_complete else {})}}`.
8. `RateLimited`/`OutOfTime` from steps 2–3 → return `{"state": params state unchanged, "data": None}`. `NeedsAuth`/`Transient` propagate.

- [ ] **Step 1: Write the failing tests** (FakeHttp routes for summary, positions, three history endpoints, instruments; `Ctx` simple object with `secrets`/`config`)

```python
def test_first_sync_full_history():        # all endpoints one page -> data has account with deposit + dividend, holdings with the position and its fill trades; state orders_complete True
def test_backfill_not_finished_leaves_holdings_out():  # orders page1 rate-limited after -> "holdings" not in data; state["pending"] has the fills; account still sent
def test_second_sync_incremental():        # state from first sync; new fill on page 1 before old newest -> only the new fill's trade in holding trades (+ balancing if any)
def test_duplicate_fill_skipped():         # fill id already in recent_fills -> not added to pending
def test_account_switch_resets_state():    # state account_id "999" but summary id 10000001 -> state rebuilt, no "999" anywhere in output ids
def test_summary_rate_limited_returns_null_data():   # summary 429 with far reset -> {"state": original state, "data": None}
def test_needs_auth_propagates():          # summary 401 -> NeedsAuth
def test_instruments_fetched_once_per_day():   # two syncs within 24 h with a new ticker -> instruments called once; type "etf" applied from ETF metadata
def test_demo_environment():               # config environment "demo" -> all calls to demo host
def test_output_is_json_serialisable():    # json.dumps(result) works (no Decimal/date objects)
def test_no_secret_in_output():            # "test-secret" not in json.dumps(result) or captured stderr
```

- [ ] **Step 2: Run** `python -m pytest tests/test_plugin.py -q` — expect FAIL.
- [ ] **Step 3: Implement** `plugin.py`.
- [ ] **Step 4: Run** `python -m pytest -q` — expect PASS.
- [ ] **Step 5: Commit** `feat: add sync orchestration for Trading 212 accounts`.

---

### Task 9: Manifest, docs, icons, contract check

**Files:**
- Create: `securo-plugin.json`, `README.md`, `DESIGN.md`, `LICENSE`, `tools/make_icons.py`, `icon.png`, `logos/trading212.png`, `tests/test_manifest.py`

**Interfaces:**
- Consumes: `client.HOSTS`, `payload.LOGO`, `plugin.plugin`.

Manifest values:
- `id` `"<owner>/securo-trading212"` and `repository` `"https://github.com/<owner>/securo-trading212"` — `<owner>` is the person's GitHub username, supplied before execution (lowercase).
- `name` `{"en": "Trading 212"}`; `description` `{"en": "Syncs a Trading 212 Invest or Stocks ISA account as a connected bank, read-only: cash, cash activity, dividends, positions and trades."}`; `version` `0.1.0`; `license` `MIT`; `min_securo_version` `0.20.0`; `runtime.entrypoint` `securo_trading212.plugin:plugin`.
- `network`: both hosts, purposes `"Reads your account, positions and history with the API key you enter."` (live) and `"Same, for a Trading 212 practice (demo) account."` (demo).
- `contributes.integrations[0]`: `key "api"`, `name {"en": "Trading 212 API key"}`, `description {"en": "Use an API key with read-only permissions: account, portfolio, history (orders, dividends, transactions) and metadata."}`, `auth "credentials"`, fields `api_key` (label "API key", secret), `api_secret` (label "API secret", secret), `environment` (label "Environment: live or demo (default live)", `required: false`), `sync_minutes 60`, `provides ["accounts","transactions","holdings","trades"]`.
- `logos {"trading212": "logos/trading212.png"}`.

- [ ] **Step 1: Write the failing test** `tests/test_manifest.py`

```python
def test_manifest_matches_code():
    m = json.loads(Path("securo-plugin.json").read_text("utf-8"))
    assert {n["host"] for n in m["network"]} == set(client.HOSTS.values())
    assert m["runtime"]["entrypoint"] == "securo_trading212.plugin:plugin"
    integ = m["contributes"]["integrations"][0]
    assert {f["key"] for f in integ["fields"]} == {"api_key", "api_secret", "environment"}
    assert all(f.get("secret") for f in integ["fields"] if f["key"] != "environment")
    assert payload.LOGO in m["logos"] and Path(m["logos"][payload.LOGO]).is_file()
    assert re.fullmatch(r"[a-z0-9-]+/securo-trading212", m["id"])
    assert "api_scopes" not in m
def test_icons_are_small_pngs():
    for p in ("icon.png", "logos/trading212.png"):
        data = Path(p).read_bytes()
        assert data[:8] == b"\x89PNG\r\n\x1a\n" and len(data) <= 64 * 1024
```

- [ ] **Step 2: Run** `python -m pytest tests/test_manifest.py -q` — expect FAIL.
- [ ] **Step 3: Write** `tools/make_icons.py` (stdlib `zlib`/`struct` PNG writer: 256×256, a deep-blue rounded square with three ascending white bars — an original mark, no Trading 212 artwork), run `python tools/make_icons.py`, then write the manifest, MIT `LICENSE` (copyright the person's name from `git config user.name`), `README.md` (what it syncs; creating a read-only API key in the Trading 212 app; connecting in Securo via **+ Connect Bank**; demo option; first sync may take several syncs for long histories; **beta** note asking for reports of mismatched positions/gains; what hosts it reaches; dev command `python -m pytest -q`; local install via Securo's `build_index.py` as in the docs), and `DESIGN.md` (decisions D1… from the spec's "Calls made by me" and Verification sections, IBKR-style table).
- [ ] **Step 4: Run** `python -m pytest -q` — expect PASS.
- [ ] **Step 5: Contract check against Securo's own validator.** In the scratchpad: `git clone --depth 1 https://github.com/securo-finance/securo`, create a venv with `pydantic`, and run a script that builds the payload from `tests/test_plugin.py::test_first_sync_full_history`'s fixtures and calls `app.plugins.contract.parse_payload(data, provides=[...], logos=["trading212"], hosts=[...])` with `PYTHONPATH=<clone>/backend`. Expected: returns a `Payload` without `PayloadError`. If importing `app.providers.base` needs packages that won't install, copy `contract.py` + the dataclasses it imports into the scratch dir and validate with those. Report the outcome either way; don't commit the script.
- [ ] **Step 6: Commit** `docs: add manifest, README, design notes and icons`.

---

## Final verification

- [ ] `python -m pytest -q` — all pass.
- [ ] `git grep -nE "[0-9]{8,}" -- tests` shows only the made-up account id `10000001` and timestamps.
- [ ] `git grep -niE "secret|api_key" -- securo_trading212` shows no literal credentials, only field names.
